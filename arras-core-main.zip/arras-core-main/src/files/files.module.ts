import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Element, ElementSchema } from 'src/elements/schema/elements.schema';
import { Products, ProductsSchema } from 'src/products/schema/products.schema';
import { StaticContent, StaticContentSchema } from 'src/static-contents/schema/static-contents.schema';
import { FilesController } from './files.controller';
import { FilesService } from './files.service';
import { File, FileSchema } from './schema/file.schema';

@Module({
  imports: [
    MongooseModule.forFeatureAsync([
      { name: File.name,  useFactory: () => FileSchema }, 
      { name: StaticContent.name,  useFactory: () => StaticContentSchema },
      { name: Element.name, useFactory: () => ElementSchema },
      { name: Products.name, useFactory: () => ProductsSchema }
    ])],
  controllers: [FilesController],
  providers: [FilesService],
  exports: [FilesService],
})
export class FilesModule {}
