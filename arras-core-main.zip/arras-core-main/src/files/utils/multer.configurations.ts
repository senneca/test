import { diskStorage } from 'multer';
import { existsSync, mkdirSync } from 'fs';
import { BadRequestException } from '@nestjs/common';


// Multer upload options
export const multerOptions = {
  // Check the mimetypes to allow for upload TODO Remove txt after test
  fileFilter: (req: any, file: Express.Multer.File, cb: any) => {
    if (checkMimeTypeSupported(file.mimetype)) {
      // Allow storage of file
      cb(null, true);
    } else {
      // Reject file
      cb(new BadRequestException('FILE_TYPE_NOT_SUPPORTED'));
    }
  },
  // Storage properties
  storage: diskStorage({
    // Destination storage path details
    destination: (req: any, file: any, cb: any) => {
      const uploadPath = process.env.BASEPATH;
        
        // Create folder if doesn't exist
        if (!existsSync(uploadPath)) {
          mkdirSync(uploadPath);
        }

        cb(null, uploadPath);
    },
    // File modification details
    filename: (req: any, file: any, cb: any) => {
      const uploadPath = process.env.BASEPATH;
      let i=1;
      let currentfileName = file.originalname;
      
      //If filename exist, rename with prefix x_filename
      while (existsSync(uploadPath + currentfileName)) {
        console.log('file exists on ' + uploadPath + currentfileName); 
        if(currentfileName.match('\^\[0-9\]*_')){
          const digits = currentfileName.indexOf('_');
          currentfileName = currentfileName.substring(digits+1);
        }
       
        currentfileName = `${i}_${currentfileName}`;
        i+=1;  
      }

      // Calling the callback passing the random name generated with the original extension name
      cb(null, `${currentfileName}`);
    },
  }),
};

function checkMimeTypeSupported(mimetype: string): boolean {
  const listSupported = process.env.FILE_SUPPORTED_LIST.split(',');
  const check = listSupported.filter((x) => mimetype.startsWith(x));
  return check.length > 0;
}
