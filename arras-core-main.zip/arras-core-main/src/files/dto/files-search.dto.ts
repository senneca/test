import { IsEnum, IsNumber, IsOptional, IsString } from "class-validator";

export class SearchFilesDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    filename: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByFilename: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    alias: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByAlias: string;


    @IsOptional()
    @IsEnum(['asc', 'desc'])
    mimetype: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByMimetype: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    size: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterBySize: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    path: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByPath: string;

    @IsOptional()
    @IsString()
    filterByPage: string;

    @IsOptional()
    @IsString()
    filterByElement: string;

    @IsOptional()
    @IsString()
    filterByCruises: string;
}