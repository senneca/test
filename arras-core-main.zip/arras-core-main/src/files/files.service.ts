import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { ObjectId } from 'mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { Element, ElementDocument } from 'src/elements/schema/elements.schema';
import {
  Products,
  ProductsDocument,
} from 'src/products/schema/products.schema';
import {
  StaticContent,
  StaticContentDocument,
} from 'src/static-contents/schema/static-contents.schema';
import { UploadFileDto } from './dto/upload-file.dto';
import { File, FileDocument } from './schema/file.schema';

@Injectable()
export class FilesService {
  constructor(
    @InjectModel(File.name) private fileModel: PaginateModel<FileDocument>,
    @InjectModel(StaticContent.name)
    private pagesModel: PaginateModel<StaticContentDocument>,
    @InjectModel(Element.name)
    private elementsModel: PaginateModel<ElementDocument>,
    @InjectModel(Products.name)
    private productsModel: PaginateModel<ProductsDocument>,
    private serviceConfig: ConfigService,
  ) {}

  uploadFile(file: Express.Multer.File): Promise<File> {
    var uploadFileDto = new UploadFileDto();
    uploadFileDto.filename = file.filename;
    uploadFileDto.mimetype = file.mimetype;
    uploadFileDto.path =
      this.serviceConfig.get<string>('BASEPATH').replace('public/', 'api/') +
      file.filename;
    uploadFileDto.size = file.size;
    uploadFileDto.alias = this.generateAliasName(file.filename);

    const createdUploadFileInstance = new this.fileModel(uploadFileDto);
    return createdUploadFileInstance.save();
  }

  private generateAliasName(value: string) {
    if (value.split('.')[0])
      return value
        .split('.')[0]
        .toString() // Convert to string
        .normalize('NFD') // Change diacritics
        .replace(/[\u0300-\u036f]/g, '') // Remove illegal characters
        .replace(/\s+/g, '-') // Change whitespace to dashes
        .toLowerCase() // Change to lowercase
        .replace(/&/g, '-and-') // Replace ampersand
        .replace(/[^a-z0-9\-]/g, '') // Remove anything that is not a letter, number or dash
        .replace(/-+/g, '-') // Remove duplicate dashes
        .replace(/^-*/, '') // Remove starting dashes
        .replace(/-*$/, '');
    // Remove trailing dashes
    else
      return value
        .toString() // Convert to string
        .normalize('NFD') // Change diacritics
        .replace(/[\u0300-\u036f]/g, '') // Remove illegal characters
        .replace(/\s+/g, '-') // Change whitespace to dashes
        .toLowerCase() // Change to lowercase
        .replace(/&/g, '-and-') // Replace ampersand
        .replace(/[^a-z0-9\-]/g, '') // Remove anything that is not a letter, number or dash
        .replace(/-+/g, '-') // Remove duplicate dashes
        .replace(/^-*/, '') // Remove starting dashes
        .replace(/-*$/, ''); // Remove trailing dashes
  }

  /*
  uploadFileXml(file: Express.Multer.File): Promise<File> {
    var uploadFileDto = new UploadFileDto();

    uploadFileDto.filename = file.filename;

    uploadFileDto.mimetype = file.mimetype;

      const fullPathWithName = this.serviceConfig.basepath + this.serviceConfig.xmlPath + file.filename;
      uploadFileDto.path = fullPathWithName != '' ? fullPathWithName : '';

      uploadFileDto.size = file.size;

    const createdUploadFileInstance = new this.fileModel(uploadFileDto);
    return createdUploadFileInstance.save();
  }
*/
  async findAllUploadedFiles(
    pi: number,
    ps: number,
    filename,
    filterByFilename,
    alias,
    filterByAlias,
    mimetype,
    filterByMimetype,
    size,
    filterBySize,
    path,
    filterByPath,
    filterByPage,
    filterByElement,
    filterByCruises,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};
    let $ids: ObjectId[] = [];

    if (filterByFilename) {
      query.filename = { $regex: '.*' + filterByFilename + '.*' };
    }
    if (filterByAlias) {
      query.alias = { $regex: '.*' + filterByAlias + '.*' };
    }
    if (filterByMimetype) {
      query.mimetype = { $regex: '.*' + filterByMimetype + '.*' };
    }
    if (filterBySize) {
      query.size = { $regex: '.*' + filterBySize + '.*' };
    }
    if (filterByPath) {
      query.path = { $regex: '.*' + filterByPath + '.*' };
    }

    if (filterByPage) {
      const item = await this.pagesModel.findById(filterByPage);
      if (item && item.files && item.files.length > 0) {
        item.files.forEach((element) => {
          $ids.push(element._id);
        });
      }
    }

    if (filterByElement) {
      const item = await this.elementsModel.findById(filterByElement);
      if (item && item.files && item.files.length > 0) {
        item.files.forEach((element) => {
          $ids.push(element._id);
        });
      }
    }

    if (filterByCruises) {
      const item = await this.productsModel.findById(filterByCruises);
      if (item && item.files && item.files.length > 0) {
        item.files.forEach((element) => {
          $ids.push(element._id);
        });
      }
    }

    if (filterByPage || filterByElement || filterByCruises) {
      query._id = { $in: $ids };
    }

    if (filename) {
      options.sort = { filename };
    } else if (alias) {
      options.sort = { alias };
    } else if (mimetype) {
      options.sort = { mimetype };
    } else if (size) {
      options.sort = { size };
    } else if (path) {
      options.sort = { path };
    }

    return this.fileModel.paginate(query, options);
  }

  findOneByFilename(filename: string): Promise<File> {
    return this.fileModel.findOne({ filename }).exec();
  }

  findOneById(id: string): Promise<File> {
    return this.fileModel.findById(id);
  }

  removeFileOnFsByPath(path: string): boolean {
    var fs = require('fs');

    try {
      path = path.replace('api/', 'public/');
      fs.unlinkSync(path);
      console.log(path + ' deleted on FS.');
      return true;
    } catch (err) {
      console.log(path + ' ' + err);
      return false;
    }
  }

  removeFileByFilename(fileName: string) {
    return this.fileModel.findOneAndDelete({ filename: fileName });
  }

  updateAliasById(id: string, value: any) {
    return this.fileModel.findByIdAndUpdate(id, {
      alias: value.alias,
    });
  }
}
