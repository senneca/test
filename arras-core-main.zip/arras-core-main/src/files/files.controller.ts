import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { FilesService } from './files.service';
// import { multerOptionsXml } from './utils/multer-xml.configurations';
import { multerOptions } from './utils/multer.configurations';
import { SearchFilesDto } from './dto/files-search.dto';
import { ConfigService } from '@nestjs/config';

@Injectable()
@Controller('files')
export class FilesController {
  constructor(
    private readonly filesService: FilesService, private configService: ConfigService
  ) {}

  /*
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post('xml/upload')
  @UseInterceptors(
    FileInterceptor('file', multerOptionsXml),
  )
  uploadXmlFile(@UploadedFile() file: Express.Multer.File) {
  
    //Check FileSize if filesize exceeded remove file on fs
    if(this.configService.get<Number>('MAX_FILE_SIZE') < file.size){
      this.filesService.removeFileOnFsByPath(file.path);
      throw new BadRequestException('FILE_SIZE_LIMIT_EXCEEDED');
    }

    return this.filesService.uploadFileXml(file).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('FILENAME_ALREADY_EXISTS');
      }
      throw new BadRequestException('FILE_IS_NOT_VALID');
    });
  }
*/
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post('upload')
  @UseInterceptors(
    FileInterceptor('file', multerOptions),
  )
  uploadAnyFile(@UploadedFile() file: Express.Multer.File) {
    
    //Check FileSize if filesize exceeded remove file on fs
    if(this.configService.get<Number>('MAX_FILE_SIZE') < file.size){
      this.filesService.removeFileOnFsByPath(file.path);
      throw new BadRequestException('FILE_SIZE_LIMIT_EXCEEDED');
    }

    return this.filesService.uploadFile(file).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('FILENAME_ALREADY_EXISTS');
      }
      throw new BadRequestException('FILE_IS_NOT_VALID');
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findUploadedFileById(@Param('id') id: string){
    return this.filesService.findOneById(id).then((u) => {
      if (!u) {
        throw new NotFoundException();
      }
      return u;
    });
  }
  
  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllUploadedFiles(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchFilesDto){
    return this.filesService.findAllUploadedFiles(
      pi,
      ps,
      params.filename,
      params.filterByFilename,
      params.alias,
      params.filterByAlias,
      params.mimetype,
      params.filterByMimetype,
      params.size,
      params.filterBySize,
      params.path,
      params.filterByPath,
      params.filterByPage,
      params.filterByElement,
      params.filterByCruises
    )
  }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':filename')
  removeFileByName(@Param('filename') filename: string) {
    return this.filesService.findOneByFilename(filename).then((u) => {
      if(!u){
        throw new NotFoundException("FILE_NOT_FOUND_ON_DB");

      } else if (this.filesService.removeFileOnFsByPath(u.path)){
        return this.filesService.removeFileByFilename(u.filename)
      } else {
        throw new NotFoundException("FILE_NOT_FOUND_ON_FS");
      }
    });
    }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('alias/:id')
  updateAlias(@Param('id') id: string, @Body() alias: {alias: string}) {
    return this.filesService.updateAliasById(id, alias).catch((u) => {
      if(u)
        throw new NotFoundException("ALIAS_NOT_FOUND_ON_DB"); 
    });
    }

}
