import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { User } from 'src/users/schema/user.schema';
import { UsersService } from '../users/users.service';
import { JwtPayload } from './jwt.payload';

@Injectable()
export class AuthService {
    constructor(
        private usersService: UsersService,
        private jwtService: JwtService
      ) {}

  async validateUser(email: string, pass: string): Promise<any> {
    const user: any = await this.usersService.findOneByEmail(email);
    if (user) {
      const check = await user.comparePassword(pass);
      if (check) {        
        return user;  
      }
    }
    return null;
  }

  async login(user: User) {
    const payload: JwtPayload = { email: user.email, role: user.role };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
