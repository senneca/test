import { Role } from "src/enums/role.enum";

export interface JwtPayload { email: string; role: Role }
