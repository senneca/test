import { Prop, raw } from "@nestjs/mongoose";
import { CabinsSchema } from "./cabins.schema";

export class PricesSchema{

@Prop({ required: false })
from: string;

@Prop(raw({
    price: {type: Number},
    discount: { type: Number}
}))
bestPrice: Object;

@Prop({type: CabinsSchema})
  cabins: CabinsSchema[];   
}