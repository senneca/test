import { Prop, raw } from "@nestjs/mongoose";

export class CabinsSchema {

@Prop({ required: true })
title: string;

@Prop({ required: true })
type: string;

@Prop({ required: true })
from: Date;

@Prop({ required: true })
to: Date;

@Prop({ required: true })
discount: number;

@Prop({ required: true, default: false })
soldout: boolean;

@Prop(raw({
     adulti: {type: Number},
     bambini: {type: Number},
     price: {type: Number}}))
prices: Record<string, any>[];
}