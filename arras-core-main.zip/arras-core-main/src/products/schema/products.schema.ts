import { Prop, raw, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { Document } from 'mongoose';
import { Attribute } from 'src/attributes/schema/attributes.schema';
import { File } from 'src/files/schema/file.schema';
import { Element } from 'src/elements/schema/elements.schema';
import { PricesSchema } from './prices.schema';
import { Categories } from 'src/categories/schema/categories.schema';


export type ProductsDocument = Products & Document;

@Schema({ timestamps: true})
export class Products {

  @Prop({ required: true })
  title: string;

  @Prop({ required: true })
  alias: string;

  @Prop({ required: false, default: 0})
  order: number;

  @Prop({ required: true })
  description: string;

  @Prop({ required: true })
  shortDescription: string;

  @Prop({ required: true })
  company: string;

  @Prop({ required: true })
  ship: string;

  @Prop({ required: true })
  shipValue: string;
  
  @Prop({ required: false, default: false })
  private: boolean;

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: Attribute.name }] })
  extras: Attribute[];

  @Prop(raw({
    price: {type: Number},
    discount: {type: Number},
    city: {
      location: {type: String},
      alias:{ type: String}
    }
  }))
  bestPrice: Record<string, any>;

  @Prop({type: PricesSchema})
  prices: PricesSchema[];

  @Prop({type: [{
    location: {type: String},
    alias: {type: String},
    element: { type: mongoose.Schema.Types.ObjectId, ref: Element.name},
    in: {type: String},
    out: {type: String},
    startPoint: {type: Boolean},
  }]})
  route: { location: string,
            alias: string,
            element: Element,
            in: string,
            out: string,
            startPoint: boolean}[];

  @Prop({default: []})
  tags: Array<string>; 

  @Prop({
    type: [{ type: mongoose.Schema.Types.ObjectId, ref: Categories.name }],
  })
  categories: Categories[];

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: Element.name }] })
  elements: Element[];

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }] })
  files: File[];

  @Prop({type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }]})
  thumbnail: File[];

  @Prop({type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }]})
  header: File[];

  @Prop({ required: false })
  publicationDate: string;

  @Prop({ required: false })
  published: boolean;

  @Prop(raw({
    title: {type: String},
    description: {type: String},
    keywords: {type: Array<String>()},
    snippetFacebook: {
      title: {type: String},
      description: {type: String},
      image: { type: mongoose.Schema.Types.ObjectId, ref: File.name }
    },
    snippetGoogle: {title: {type: String},
    description: {type: String}
  }}))
  seo: Record<string, any>;
 
}

export const ProductsSchema = SchemaFactory.createForClass(Products);
