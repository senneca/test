import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AttributesService } from 'src/attributes/attributes.service';
import {
  Attribute,
  AttributeSchema,
} from 'src/attributes/schema/attributes.schema';
import { Relation, RelationSchema } from 'src/tasks/schema/relation.schema';
import { ProductsController } from './products.controller';
import { ProductsService } from './products.service';
import { Products, ProductsSchema } from './schema/products.schema';

@Module({
  imports: [
    MongooseModule.forFeatureAsync([
      { name: Products.name, useFactory: () => ProductsSchema },
      { name: Attribute.name, useFactory: () => AttributeSchema },
      { name: Relation.name, useFactory: () => RelationSchema },
    ]),
  ],

  controllers: [ProductsController],
  providers: [ProductsService, AttributesService],
  exports: [ProductsService],
})
export class ProductsModule {}
