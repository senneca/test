import {
    IsNotEmpty,
    IsNumber,
  } from 'class-validator';
  
  export class PricesDetails {
   
    @IsNotEmpty()
    @IsNumber()
    adulti: number;
  
    @IsNotEmpty()
    @IsNumber()
    bambini: number;
   
    @IsNotEmpty()
    @IsNumber()
    price: number;
  
  }
  