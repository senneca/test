import {
  IsOptional,
    IsString,
    IsBoolean,
    IsArray,
    IsObject,
    IsNumber,
    IsNotEmpty,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { SeoDto } from 'src/static-contents/dto/seo-content';
import { BestPriceDto } from './best-price.dto';
import { PricesDto } from './prices.dto';
import { RoutesDto } from './routes.dto';
  
  export class EditProductDto {

    @IsNotEmpty()
    @IsString()
    title: string;
  
    @IsNotEmpty()
    @IsString()
    alias: string;
  
    @IsOptional()
    @IsNumber()
    order: number;

    @IsNotEmpty()
    @IsString()
    description: string;
  
    @IsOptional()
    @IsString()
    shortDescription: string;
  
    @IsOptional()
    @IsString()
    company: string;
  
    @IsOptional()
    @IsString()
    ship: string;
    
    @IsOptional()
    @IsString()
    shipValue: string;

    @IsOptional()
    @IsBoolean()
    private: boolean;
  
    @IsOptional()
    @IsArray()
    extras: Array<ObjectId>;
  
    @IsOptional()
    @IsObject()
    bestPrice: BestPriceDto;
  
    @IsOptional()
    @IsArray()
    prices: PricesDto[];
  
    @IsOptional()
    @IsArray()
    route: RoutesDto[];
  
    @IsOptional()
    @IsArray()
    tags: Array<string>; 
  
    @IsOptional()
    @IsArray()
    elements: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    categories?: Array<ObjectId>;
  
    @IsOptional()
    @IsArray()
    files: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    thumbnail: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    header: Array<ObjectId>;

    @IsOptional()
    @IsString()
    publicationDate: string;

    @IsOptional()
    @IsBoolean()
    published: boolean;

    @IsOptional()
    @IsObject()
    seo?: SeoDto;
  }
  