import {
    IsBoolean,
    IsNotEmpty,
    IsOptional,
    IsString,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
  
  export class RoutesDto {
   
    @IsNotEmpty()
    @IsString()
    location: string;
  
    @IsNotEmpty()
    @IsString()
    alias: string;

    @IsOptional()
    @IsString()
    in: string;

    @IsOptional()
    @IsString()
    out: string;
   
    @IsOptional()
    @IsString()
    element: ObjectId;

    @IsNotEmpty()
    @IsBoolean()
    startPoint: boolean;
  
  }
  