import { IsArray, IsBooleanString, IsDateString, IsEnum, IsNumber, IsNumberString, IsOptional, IsString } from "class-validator";

export class SearchProductDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    title: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByTitle: string;

    @IsOptional()
    @IsString()
    order: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    publicationDate: 'asc' | 'desc';

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    company: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByCompany: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    ship: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByShip: string;

    @IsOptional()
    @IsString()
    filterByKeyword: string;

    @IsOptional()
    @IsDateString()
    filterByDateFrom: Date;

    @IsOptional()
    @IsDateString()
    filterByDateTo: Date;

    @IsOptional()
    @IsNumberString()
    filterByBestPriceMin: number;

    @IsOptional()
    @IsNumberString()
    filterByBestPriceMax: number;

    @IsOptional()
    @IsBooleanString()
    filterByPrivate: boolean;

    @IsOptional()
    @IsBooleanString()
    filterByFeatured: boolean;

    @IsOptional()
    @IsBooleanString()
    filterBySpecialOffers: boolean;
 
    
}