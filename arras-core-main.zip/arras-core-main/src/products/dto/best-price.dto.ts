import {
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
  } from 'class-validator';
  
  export class BestPriceDto {
   
    @IsNotEmpty()
    @IsNumber()
    price: number;
  
    @IsNotEmpty()
    @IsNumber()
    discount: number;
   
    @IsOptional()
    @IsObject()
    city: {location: String, alias: String};
  
  }
  