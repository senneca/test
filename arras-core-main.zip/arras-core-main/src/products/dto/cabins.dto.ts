import {
    IsArray,
  IsBoolean,
    IsNotEmpty,
    IsNumber,
    IsOptional,
    IsString,
  } from 'class-validator';
import { PricesDetails } from './prices-details.dto';
  
  export class CabinsDto {
   
    @IsNotEmpty()
    @IsString()
    title: string;
  
    @IsNotEmpty()
    @IsString()
    type: string;

    @IsNotEmpty()
    @IsString()
    from: string;
  
    @IsNotEmpty()
    @IsString()
    to: string;
  
    @IsNotEmpty()
    @IsArray()
    prices: PricesDetails[];
   
    @IsNotEmpty()
    @IsNumber()
    discount: number;

    @IsOptional()
    @IsBoolean()
    soldout: boolean;
  
  }
  