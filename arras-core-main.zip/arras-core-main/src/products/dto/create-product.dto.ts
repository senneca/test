import {
    IsArray,
    IsBoolean,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { SeoDto } from 'src/static-contents/dto/seo-content';
import { BestPriceDto } from './best-price.dto';
import { PricesDto } from './prices.dto';
import { RoutesDto } from './routes.dto';
  
  export class CreateProductDto {
   
    @IsNotEmpty()
    @IsString()
    title: string;
  
    @IsNotEmpty()
    @IsString()
    alias: string;
  
    @IsNotEmpty()
    @IsString()
    description: string;
  
    @IsNotEmpty()
    @IsString()
    shortDescription: string;
  
    @IsNotEmpty()
    @IsString()
    company: string;
  
    @IsNotEmpty()
    @IsString()
    ship: string;

    @IsNotEmpty()
    @IsString()
    shipValue: string;
    
    @IsOptional()
    @IsBoolean()
    private: boolean;
  
    @IsOptional()
    @IsArray()
    extras: Array<ObjectId>;
  
    @IsOptional()
    @IsObject()
    bestPrice: BestPriceDto;
  
    @IsOptional()
    @IsArray()
    prices: PricesDto[];
  
    @IsOptional()
    @IsArray()
    route: RoutesDto[];
  
    @IsOptional()
    @IsArray()
    tags: Array<string>; 
  
    @IsOptional()
    @IsArray()
    elements: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    categories?: Array<ObjectId>;
  
    @IsOptional()
    @IsArray()
    files: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    thumbnail: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    header: Array<ObjectId>;

    @IsNotEmpty()
    @IsString()
    publicationDate: string;

    @IsNotEmpty()
    @IsBoolean()
    published: boolean;

    @IsNotEmpty()
    @IsObject()
    seo?: SeoDto;

  }
  