import {
    IsArray,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
  } from 'class-validator';
import { BestPriceDto } from './best-price.dto';
import { CabinsDto } from './cabins.dto';
  
  export class PricesDto {
   
    @IsNotEmpty()
    @IsString()
    from: string;
  
    @IsNotEmpty()
    @IsObject()
    bestPrice: BestPriceDto;
   
    @IsOptional()
    @IsArray()
    cabins: CabinsDto[];
  
  }
  