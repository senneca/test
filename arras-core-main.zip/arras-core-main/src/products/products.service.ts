import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, ObjectId } from 'mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import {
  Attribute,
  AttributeDocument,
} from 'src/attributes/schema/attributes.schema';
import { Element } from 'src/elements/schema/elements.schema';
import { File } from 'src/files/schema/file.schema';
import { Relation, RelationDocument } from 'src/tasks/schema/relation.schema';
import { CreateProductDto } from './dto/create-product.dto';
import { EditProductDto } from './dto/edit-product.dto';
import { Products, ProductsDocument } from './schema/products.schema';

@Injectable()
export class ProductsService {
  constructor(
    @InjectModel(Products.name)
    private productModel: PaginateModel<ProductsDocument>,

    @InjectModel(Attribute.name)
    private attributesModel: PaginateModel<AttributeDocument>,

    @InjectModel(Relation.name)
    private relationModel: PaginateModel<RelationDocument>,
  ) {}

  deleteRelation(_id) {
    this.relationModel
      .deleteMany({
        $or: [{ product1: _id }, { product2: _id }],
      })
      .exec()
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  async create(createProductDto: CreateProductDto): Promise<Products> {
    const createdProduct = new this.productModel(createProductDto);
    return createdProduct.save();
  }

  findAllCruises(
    pi: number,
    ps: number,
    title,
    filterByTitle,
    order,
    publicationDate,
    company,
    filterByCompany,
    ship,
    filterByShip,
    filterByPrivate,
    filterByFeatured,
    filterBySpecialOffers,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if (filterByTitle) {
      query.title = { $regex: '.*' + filterByTitle + '.*' };
    }
    if (filterByCompany) {
      query.company = { $regex: '.*' + filterByCompany + '.*' };
    }
    if (filterByShip) {
      query.shipValue = { $regex: '.*' + filterByShip + '.*' };
    }
    if (filterByPrivate) {
      if (filterByPrivate !== 'false') {
        query.private = true;
      } else {
        delete query.private;
      }
    }
    if (filterByFeatured || filterBySpecialOffers) {
      if (filterByFeatured !== 'false') {
        query.tags = { $elemMatch: { $regex: 'featured', $options: 'i' } };
      } else if (filterBySpecialOffers !== 'false') {
        query.tags = { $elemMatch: { $regex: 'special', $options: 'i' } };
      } else {
        delete query.tags;
      }
    }

    if (title) {
      options.sort = { title };
    } else if (company) {
      options.sort = { company };
    } else if (ship) {
      options.sort = { ship };
    } else if (publicationDate) {
      options.sort = { publicationDate };
    } else if (order) {
      options.sort = { order };
    } else {
      options.sort = { order: 'asc', alias: 'asc' };
    }
    options.populate = ['files', 'extras'];

    return this.productModel.paginate(query, options);
  }

  async findAllRelatedCruisesShort(pi: number, ps: number, _id: any) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};
    query.product1 = _id;
    options.sort = {
      score: 'desc',
    };
    options.populate = [
      {
        path: 'product2',
        select: 'title alias shortDescription bestPrice order route',
        populate: ['files'],
      },
    ];
    return this.relationModel.paginate(query, options);
  }

  async findAllCruisesShort(
    pi: number,
    ps: number,
    title,
    filterByTitle,
    publicationDate,
    company,
    filterByCompany,
    ship,
    filterByShip,
    filterByKeyword,
    filterByExtra,
    filterByCity,
    filterByStartPoint,
    filterByDateFrom,
    filterByDateTo,
    filterByBestPriceMin,
    filterByBestPriceMax,
    privateProduct: boolean,
    filterByPrivate: boolean,
    filterByTag,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};
    let $and: any[] = [];
    let $or: any[] = [];

    if (filterByTitle) {
      query.title = { $regex: '.*' + filterByTitle + '.*' };
    }
    if (filterByCompany) {
      query.company = { $regex: '.*' + filterByCompany + '.*' };
    }
    if (filterByShip) {
      query.shipValue = { $regex: '.*' + filterByShip + '.*' };
    }
    if (!privateProduct) {
      query.private = false;
    } else if (filterByPrivate) {
      query.private = true;
    }
    if (filterByKeyword) {
      $or.push({
        title: { $regex: '.*' + filterByKeyword + '.*', $options: 'i' },
      });
      $or.push({
        description: { $regex: '.*' + filterByKeyword + '.*', $options: 'i' },
      });
      $or.push({
        shortDescription: {
          $regex: '.*' + filterByKeyword + '.*',
          $options: 'i',
        },
      });
    }

    if (filterByExtra) {
      query.extras = {
        $in: filterByExtra instanceof Array ? filterByExtra : [filterByExtra],
      };
    }

    if (filterByCity) {
      query['route.alias'] = {
        $all: filterByCity instanceof Array ? filterByCity : [filterByCity],
      };
    }

    if (filterByStartPoint) {
      query['route'] = {
        $elemMatch: {
          startPoint: true,
          alias: {
            $in:
              filterByStartPoint instanceof Array
                ? filterByStartPoint
                : [filterByStartPoint],
          },
        },
      };
    }

    if (filterByDateFrom) {
      query['prices.cabins.from'] = { $gte: filterByDateFrom };
    }
    if (filterByDateTo) {
      query['prices.cabins.to'] = { $lte: filterByDateTo };
    }

    if (filterByTag) {
      query.tags = {
        $in: filterByTag instanceof Array ? filterByTag : [filterByTag],
      };
    }

    if (filterByBestPriceMin && filterByBestPriceMax) {
      $and.push({ 'bestPrice.price': { $gte: filterByBestPriceMin } });
      $and.push({ 'bestPrice.price': { $lte: filterByBestPriceMax } });
    } else if (filterByBestPriceMin) {
      query['bestPrice.price'] = { $gte: filterByBestPriceMin };
    } else if (filterByBestPriceMax) {
      query['bestPrice.price'] = { $lte: filterByBestPriceMax };
    }

    query.published = true;
    if ($and.length) {
      query.$and = $and;
    }

    if ($or.length) {
      query.$or = $or;
    }

    if (title) {
      options.sort = { title };
    } else if (company) {
      options.sort = { company };
    } else if (ship) {
      options.sort = { ship };
    } else if (publicationDate) {
      options.sort = { publicationDate };
    } else {
      options.sort = { order: 'asc', alias: 'asc' };
    }

    options.select = 'title alias shortDescription bestPrice order route thumbnail header';
    options.populate = ['files','thumbnail', 'header'];

    return this.productModel.paginate(query, options);
  }

  findOneProductById(id: string) {
    return this.productModel
      .findById(id)
      .populate('extras')
      .populate('files')
      .populate('elements')
      .populate('elements.staticPages')
      .populate('elements.files')
      .populate('elements.categories')
      .populate('route.element')
      .sort({ 'elements.order': 0 })
      .exec();
  }

  findOneProductByAlias(alias: string) {
    return this.productModel
      .findOne({ alias: alias, published: true })
      .populate({
        path: 'extras',
        model: Attribute,
        populate: {
          path: 'element',
          model: Element,
          populate: {
            path: 'files',
            model: File
          }
        },
      })
      .populate('seo.snippetFacebook.image')
      .populate('files')
      .populate('categories')
      .populate('route.element')
      .populate('elements')
      .populate('elements.staticPages')
      .populate('elements.files')
      .populate('elements.categories')
      .populate('header')
      .populate('thumbnail')
      .sort({ 'elements.order': 0 })
      .exec();
  }

  async updateProduct(id: string, dto: EditProductDto) {
    const Product = await this.productModel.findById(id);
    Product.set(dto);
    this.deleteRelation(id);
    return Product.save();
  }

  deleteProduct(id: string) {
    this.deleteRelation(id);
    return this.productModel.findByIdAndDelete(id);
  }

  updateState(id: string, state: any) {
    this.deleteRelation(id);
    return this.productModel.findByIdAndUpdate(id, {
      published: state.value,
    });
  }
}
