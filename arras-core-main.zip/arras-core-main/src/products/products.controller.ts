import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';

import { ProductsService } from './products.service';
import { CreateProductDto } from './dto/create-product.dto';
import { SearchProductDto } from './dto/search-product.dto';
import { EditProductDto } from './dto/edit-product.dto';
import { OptionalJwtAuthGuard } from 'src/auth/optional-jwt-auth.guard';

@Injectable()
@Controller('cruises')
export class ProductsController {
  constructor(private readonly productService: ProductsService) {}

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createProductDto: CreateProductDto) {
    return this.productService.create(createProductDto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('PRODUCT_EXISTS');
      }
      // throw new BadRequestException('GENERIC_ERROR');
      else console.log(err);
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('all')
  findAllProducts(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchProductDto,
  ) {
    return this.productService.findAllCruises(
      pi,
      ps,
      params.title,
      params.filterByTitle,
      params.order,
      params.publicationDate,
      params.company,
      params.filterByCompany,
      params.ship,
      params.filterByShip,
      params.filterByPrivate,
      params.filterByFeatured,
      params.filterBySpecialOffers,
    );
  }

  @UseGuards(OptionalJwtAuthGuard)
  @Get()
  findAllCruises(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchProductDto,
    @Query('filterByExtra') filterByExtra: string[],
    @Query('filterByCity') filterByCity: string[],
    @Query('filterByStartPoint') filterByStartPoint: string[],
    @Query('filterByTag') filterByTag: string[],

    @Req() request,
  ) {
    return this.productService
      .findAllCruisesShort(
        pi,
        ps,
        params.title,
        params.filterByTitle,
        params.publicationDate,
        params.company,
        params.filterByCompany,
        params.ship,
        params.filterByShip,
        params.filterByKeyword,
        filterByExtra,
        filterByCity,
        filterByStartPoint,
        params.filterByDateFrom,
        params.filterByDateTo,
        params.filterByBestPriceMin,
        params.filterByBestPriceMax,
        request.user && request.user.email ? true : false,
        params.filterByPrivate,
        filterByTag,
      )
      .catch((err) => {
        throw err;
      });
  }

  @Get('alias/:alias')
  findProduct(@Param('alias') alias: string) {
    return this.productService
      .findOneProductByAlias(alias)
      .then((product) => {
        if (!product) {
          throw new NotFoundException('PRODUCT_NOT_FOUND');
        }
        return product;
      }); 
  }

  @Get('alias/:alias/related')
  findProductRelated(
    @Param('alias') alias: string,
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
  ) {
    return this.productService
      .findOneProductByAlias(alias)
      .then((p) => {
        return this.productService.findAllRelatedCruisesShort(pi, ps, p._id);
      })
      .catch((err) => {
        throw err;
      });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findProductById(@Param('id') id: string) {
    return this.productService.findOneProductById(id).catch((err) => {
      if (err) {
        throw new NotFoundException('PRODUCT_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editProduct(@Param('id') id: string, @Body() dto: EditProductDto) {
    return this.productService.updateProduct(id, dto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_TITLE_PRODUCT');
      } else {
        throw new NotFoundException('PRODUCT_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeProduct(@Param('id') id: string) {
    return this.productService.deleteProduct(id).catch((err) => {
      if (err) {
        throw new NotFoundException('PRODUCT_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('product/:id')
  PublishProduct(@Param('id') id: string, @Body() value: { value: boolean }) {
    return this.productService.updateState(id, value).catch((err) => {
      if (err) {
        throw new NotFoundException('CRUISE_NOT_FOUND');
      }
      throw err;
    });
  }
}
