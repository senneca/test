import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import {
  ElementSchema,
} from './schema/elements.schema';
import { ElementsController } from './elements.controller';
import { ElementsService } from './elements.service';
import {Element} from './schema/elements.schema';


@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Element.name, schema: ElementSchema },
    ]),
  ],
  controllers: [ElementsController],
  providers: [ElementsService],
  exports: [ElementsService],
})
export class ElementsModule {}
