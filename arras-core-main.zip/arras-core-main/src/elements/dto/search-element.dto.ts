import { IsEnum, IsOptional, IsString } from "class-validator";

export class SearchElementsDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    title: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByTitle: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    alias: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByAlias: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    order: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByOrder: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    publicationDate: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByPublicationDate: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    author: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByAuthor: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    category: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByCategory: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    staticPages: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByPage: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    position: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByPosition: string;
    
}