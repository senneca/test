import {
    IsArray,
  IsDate,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
  
  export class EditElementDto {

    @IsNotEmpty()
    @IsNumber()
    order: number;

    @IsNotEmpty()
    @IsString()
    title: string;
    
    @IsOptional()
    @IsString()
    subtitle: string;
  
    @IsOptional()
    @IsString()
    alias: string;

    @IsOptional()
    @IsString()
    link: string;

    @IsOptional()
    @IsString()
    content: string;
  
    @IsOptional()
    @IsString()
    shortDescription: string;
    
    @IsOptional()
    @IsString()
    author: string;

    @IsOptional()
    @IsString()
    publicationDate: string;

    @IsOptional()
    @IsArray()
    files?: Array<ObjectId>;
  
    @IsOptional()
    @IsArray()
    categories?: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    tags?: Array<string>;

    @IsOptional()
    @IsString()
    position?: string;

    @IsOptional()
    @IsString()
    staticPages?: ObjectId;
  }
  