import {
    IsArray,
    IsBoolean,
    IsDate,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
  
  export class CreateElementDto {

    @IsNotEmpty()
    @IsNumber()
    order: number;

    @IsNotEmpty()
    @IsString()
    title: string;

    @IsOptional()
    @IsString()
    subtitle: string;
  
    @IsNotEmpty()
    @IsString()
    @MinLength(3)
    alias: string;

    @IsOptional()
    @IsString()
    link: string;

    @IsOptional()
    @IsString()
    content: string;

    @IsOptional()
    @IsString()
    shortDescription: string;

    @IsOptional()
    @IsBoolean()
    published: boolean;

    @IsOptional()
    @IsString()
    publicationDate: string;

    @IsOptional()
    @IsString()
    author: string;
  
    @IsOptional()
    @IsArray()
    files?: Array<ObjectId>;
  
    @IsOptional()
    @IsArray()
    categories?: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    tags?: Array<string>;

    @IsOptional()
    @IsString()
    position?: string;

    @IsOptional()
    @IsString()
    staticPages?: ObjectId;

  }
  