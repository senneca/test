import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { CreateElementDto } from './dto/create-element.dto';
import { EditElementDto } from './dto/edit-element.dto';
import { Element, ElementDocument } from './schema/elements.schema';

@Injectable()
export class ElementsService {
  constructor(
    @InjectModel(Element.name)
    private elementModel: PaginateModel<ElementDocument>,
  ) {}

  async create(
    createElementDto: CreateElementDto,
    author: string,
  ): Promise<Element> {
    if (author && author !== '') {
      createElementDto.author = author;
    }
    const createdElement = new this.elementModel(createElementDto);
    return createdElement.save();
  }

  findAllElements(
    pi: number,
    ps: number,
    title,
    filterByTitle,
    order,
    filterByOrder,
    alias,
    filterByAlias,
    publicationDate,
    filterByPublicationDate,
    author,
    filterByAuthor,
    category,
    filterByCategory,
    staticPages,
    filterByPage,
    position,
    filterByPosition
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if (filterByTitle) {
      query.title = { $regex: '.*' + filterByTitle + '.*', $options: 'i' };
    }
    if (filterByOrder) {
      query.order = { $regex: '.*' + filterByOrder + '.*' };
    }
    if (filterByAlias) {
      query.alias = { $regex: '.*' + filterByAlias + '.*', $options: 'i' };
    }
    if (filterByPublicationDate) {
      query.publicationDate = { $regex: '.*' + filterByPublicationDate + '.*' };
    }
    if (filterByAuthor) {
      query.author = { $regex: '.*' + filterByAuthor + '.*' };
    }
    if (filterByCategory && filterByCategory !== 'null') {
      query.categories = { _id: filterByCategory };
    }
    if (filterByPage && filterByPage !== 'null') {
      query.staticPages = { _id: filterByPage };
    }
    if (filterByPosition) {
      query.position = { $regex: '.*' + filterByPosition + '.*' };
    }

    // Occorre sempre ordinare anche per chiave primaria o unica.
    if (title) {
      options.sort = { title, alias: 'asc'  };
    } else if (order) {
      options.sort = { order, alias: 'asc'  };
    } else if (alias) {
      options.sort = { alias };
    } else if (publicationDate) {
      options.sort = { publicationDate, alias: 'asc'  };
    } else if (author) {
      options.sort = { author, alias: 'asc'  };
    } else if (staticPages) {
      options.sort = { staticPages: staticPages, position: staticPages, order: staticPages  };
    }  else if (position) {
      options.sort = { position, alias: 'asc' };
    } else {
      options.sort = { order: 'asc', alias: 'asc' }; // se order non viene passato occorre specificarlo!
    }
    options.populate = ['files', 'categories', 'staticPages'];

    return this.elementModel.paginate(query, options);
  }

  findOneElementById(id: string) {
    return this.elementModel
      .findById(id)
      .populate('files')
      .populate('categories')
      .populate('staticPages')
      .exec();
  }

  async findElementsByAlias(alias: string): Promise<Element> {
    return await this.elementModel
      .findOne({ alias: alias, published: true })
      .populate('files')
      .populate('categories')
      .populate('staticPages')
      .exec();
  }

  async findElementsByCategory(category: string): Promise<Array<Element>> {
    return await this.elementModel
      .find({ categories: category, published: true })
      .populate('files')
      .populate('categories')
      .populate('staticPages')
      .exec();
  }

  async filterByCategory(id: string): Promise<Array<Element>> {
    let array = [];
    array.push(id);
    return await this.elementModel
      .find({ categories: { $in: array } })
      .populate('files')
      .populate('categories')
      .populate('staticPages')
      .exec();
  }

  async filterByPages(id: string): Promise<Array<Element>> {
    let array = [];
    array.push(id);
    return await this.elementModel
      .find({ staticPages: { $in: array } })
      .populate('files')
      .populate('categories')
      .populate('staticPages')
      .exec();
  }

  async updateElement(id: string, dto: EditElementDto, author: string) {
    if (author && author !== '') {
      dto.author = author;
    }
    return this.elementModel.findByIdAndUpdate(id, dto, {
      new: true,
      useFindAndModify: false,
    });
  }

  deleteElement(id: string) {
    return this.elementModel.findByIdAndDelete(id);
  }

  updateStateElement(id: string, state: any) {
    return this.elementModel.findByIdAndUpdate(id, {
      published: state.value,
    });
  }
}
