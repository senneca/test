import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { ElementsService } from './elements.service';
import * as mongoose from 'mongoose';
import { CreateElementDto } from './dto/create-element.dto';
import { SearchElementsDto } from './dto/search-element.dto';
import { EditElementDto } from './dto/edit-element.dto';


@Injectable()
@Controller('elements')
export class ElementsController {
  
  constructor(private readonly ElementService: ElementsService) {}

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createElementDto: CreateElementDto, @Req() request) {
    return this.ElementService
      .create(createElementDto, request.user.email)
      .catch((err) => {
        if (err.code === 11000) {
          throw new BadRequestException('ALIAS_ELEMENT_EXISTS');
        } else if (err instanceof mongoose.Error.ValidationError){
          throw new BadRequestException('FILE_ID_OR_CATEGORY_ID_DOES_NOT_EXISTS');
        } else 
        throw new BadRequestException('GENERIC_ERROR');
      });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllElements(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchElementsDto){
    return this.ElementService.findAllElements(
      pi,
      ps,
      params.title,
      params.filterByTitle,
      params.order,
      params.filterByOrder,
      params.alias,
      params.filterByAlias,
      params.publicationDate,
      params.filterByPublicationDate,
      params.author,
      params.filterByAuthor,
      params.category,
      params.filterByCategory,
      params.staticPages,
      params.filterByPage,
      params.position,
      params.filterByPosition)
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findElement(@Param('id') id: string){
    return this.ElementService.findOneElementById(id).catch((err) => {
      if(err){
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
      throw err;
    });
  }  

  @Get('alias/:alias')
  findElementByAlias(@Param('alias') alias: string){
    return this.ElementService.findElementsByAlias(alias).then((file) => {
      if(!file){
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
      return file;
    });
  }  

 
  @Get('category/:category')
  findElementsByCategories(@Param('category') category: string){
    return this.ElementService.findElementsByCategory(category).then((file) => {
      if(!file){
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
      return file;
    });
  }

  @Get('filter/:id')
  filterByCategoriesList(@Param('id') id: string){
    return this.ElementService.filterByCategory(id).then((file) => {
      if(!file){
        throw new NotFoundException('ELEMENT_CATEGORIES_NOT_FOUND');
      }
      return file;
    });
  }

  @Get('filter/pages/:id')
  filterByPagesList(@Param('id') id: string){
    return this.ElementService.filterByPages(id).then((file) => {
      if(!file){
        throw new NotFoundException('ELEMENT_CATEGORIES_NOT_FOUND');
      }
      return file;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editElement(@Param('id') id: string, @Body() dto: EditElementDto, @Req() request) {
    return this.ElementService.updateElement(id, dto, request.user.email).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_TITLE_ELEMENT');
      } else {
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeElement(@Param('id') id: string) {
    return this.ElementService.deleteElement(id).catch((err) => {
      if (err) {
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('element/:id')
  PublishElement(@Param('id') id: string, @Body() value: {value: boolean}) {
    return this.ElementService.updateStateElement(id, value).catch((err) => {
      if (err) {
        throw new NotFoundException('ELEMENT_NOT_FOUND');
      }
      throw err;
    });
  }
}
