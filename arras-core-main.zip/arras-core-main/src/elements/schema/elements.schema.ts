import { Prop, raw, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { Document } from 'mongoose';
import { Categories } from 'src/categories/schema/categories.schema';
import { File } from 'src/files/schema/file.schema';
import { StaticContent } from 'src/static-contents/schema/static-contents.schema';

export type ElementDocument = Element & Document;

@Schema({ timestamps: true })
export class Element {
  @Prop({ required: true })
  order: number;

  @Prop({})
  link: string;

  @Prop({ required: true })
  title: string;

  @Prop({ required: false })
  subtitle: string;

  @Prop({ required: true, unique: true })
  alias: string;

  @Prop({ required: false })
  content: string;

  @Prop({ required: false })
  shortDescription: string;

  @Prop({ required: true, default: false })
  published: boolean;

  @Prop({ required: false })
  publicationDate: string;

  @Prop({ required: true })
  author: string;

  @Prop({
    type: [{ type: mongoose.Schema.Types.ObjectId, ref: Categories.name }],
  })
  categories: Categories[];

  @Prop({ default: [] })
  tags: Array<string>;

  @Prop({ required: false })
  position: string;

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }] })
  files: File[];

  @Prop({
    type: [{ type: mongoose.Schema.Types.ObjectId, ref: StaticContent.name }],
  })
  staticPages: StaticContent;
}

export const ElementSchema = SchemaFactory.createForClass(Element);
