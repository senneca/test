import { IsArray, IsEmpty, IsNotEmpty, IsObject, IsOptional, IsString } from 'class-validator';
import { ObjectId } from 'mongoose';

export class EditCategoryDto {

  @IsOptional()
  @IsString()
  title: string;

  @IsOptional()
  @IsString()
  parent: string;

}
