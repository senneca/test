import { IsArray, IsEmpty, IsNotEmpty, IsObject, IsOptional, IsString } from 'class-validator';
import { ObjectId } from 'mongoose';

export class CreateCategoryDto {
  @IsNotEmpty()
  @IsString()
  title: string;
}
