import { IsEnum, IsOptional, IsString } from "class-validator";

export class SearchCategoriesDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    title: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByTitle: string;

}