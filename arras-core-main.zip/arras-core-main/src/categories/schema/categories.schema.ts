import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type CategoriesDocument = Categories & Document;

@Schema({ timestamps: true })
export class Categories {

  @Prop({ required: true, unique: true })
  title: string;

  @Prop({ required: false, default: true })
  expanded: boolean;
  
}

export const CategoriesSchema = SchemaFactory.createForClass(Categories);
