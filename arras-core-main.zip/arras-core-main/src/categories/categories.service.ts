import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { CreateCategoryDto } from './dto/create-category.dto';
import { EditCategoryDto } from './dto/edit-category.dto';
import {
  Categories,
  CategoriesDocument,
  CategoriesSchema,
} from './schema/categories.schema';

@Injectable()
export class CategoriesService {
  constructor(
    @InjectModel(Categories.name)
    private categoriesModel: PaginateModel<CategoriesDocument>,
  ) {}

  async create(createCategoryDto: CreateCategoryDto): Promise<Categories> {
    const createdCategory = new this.categoriesModel(createCategoryDto);
    return createdCategory.save();
  }

  async findAllCategories() {
    return await this.categoriesModel.getChildrenTree({lean: false});
  }

  findCategoryById(id: string) {
    return this.categoriesModel.findById(id).populate('parent').exec();
  }

  findCategoryByTitle(title: string) {
    return this.categoriesModel
      .findOne({ title: title })
      .populate('parent')
      .exec();
  }

  async updateCategory(idSource: string, dto: EditCategoryDto) {
    const category = await this.categoriesModel.findById(idSource);
    category.set(dto);
  
    return category.save();
/*
    return this.categoriesModel.findByIdAndUpdate(idSource, dto, {
              new: true,
              useFindAndModify: false,
            });
            */
  }

  deleteCategoryByID(id: string) {
    return this.categoriesModel.findByIdAndDelete(id);
  }
}
