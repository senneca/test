import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { CategoriesService } from './categories.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import * as mongoose from 'mongoose';
import { EditCategoryDto } from './dto/edit-category.dto';

@Injectable()
@Controller('categories')
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createCategoryDto: CreateCategoryDto) {
    return this.categoriesService
      .create(createCategoryDto)
      .catch((err) => {
        if (err.code === 11000) {
          throw new BadRequestException('CATEGORY_EXISTS');
        } else if (err instanceof mongoose.Error.ValidationError){
          throw new BadRequestException('CHILDREN_CATEGORY_DOES_NOT_EXISTS');
        } else 
        throw new BadRequestException('GENERIC_ERROR');
      });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllCategories(){
    return this.categoriesService.findAllCategories();
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findCategory(@Param('id') id: string){
    return this.categoriesService.findCategoryById(id).catch((err) => {
      if(err){
        throw new BadRequestException('CATEGORY_NOT_FOUND');
      }
      throw err;
    });
  }  

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':source')
  editCategory(@Param('source') idSource: string, @Body() dto: EditCategoryDto) {
    return this.categoriesService.updateCategory(idSource,dto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_CATEGORY');
      } else {
        throw new NotFoundException('CATEGORY_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('title/:title')
  getCategoryByTitle(@Param('title') title: string) {
    return this.categoriesService.findCategoryByTitle(title).catch((err) => {
      if (err) {
        throw new NotFoundException('CATEGORY_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeCategory(@Param('id') id: string) {
    return this.categoriesService.deleteCategoryByID(id).catch((err) => {
      if (err) {
        throw new NotFoundException('CATEGORY_NOT_FOUND');
      }
      throw err;
    });
  }

}
