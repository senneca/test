import { HttpService, Injectable, Logger } from '@nestjs/common';
import { User } from 'src/users/schema/user.schema';
import { map, switchMap, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class GetResponseService {
  private cid = this.configService.get<string>('GET_RESPONSE_CAMPAIGN_ID');
  private readonly logger = new Logger(GetResponseService.name);

  constructor(
    private readonly httpService: HttpService,
    private readonly configService: ConfigService,
  ) {}

  private createUser(user: User) {
    return this.httpService.post('contacts', this.getPayloadFromUser(user));
  }

  private updateUser(contactId: string, user: User) {
    return this.httpService.post(
      'contacts/' + contactId,
      this.getPayloadFromUser(user),
    );
  }

  update(user: User): void {
    this.getContactID(user.email)
      .pipe(
        switchMap((contactId) =>
          contactId ? this.updateUser(contactId, user) : this.createUser(user),
        ),
        map((res) => res.data),
      )
      .subscribe(
        (data) => {
          this.logger.log(
            'Successfully synchronized',
            data,
          );
        },
        (err) => {
          this.logger.error(
            'Synchronization error', err
          );
        },
      );
  }

  private getPayloadFromUser(user: User) {
    return {
      campaign: {
        campaignId: this.cid,
      },
      name:
        user.firstName && user.lastName
          ? user.firstName + ' ' + user.lastName
          : null,
      email: user.email,
    };
  }

  private getContactID(email: string): Observable<string> {
    return this.httpService
      .get('campaigns/' + this.cid + '/contacts', {
        params: { 'query[email]': email },
      })
      .pipe(
//        tap((res) => console.log('ricerca', res.data)),
        map((res) => (res.data.length ? res.data[0].contactId : null)),
      );
  }
}
