import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthModule } from './auth/auth.module';
import { UserSchema } from './users/schema/user.schema';
import { FilesModule } from './files/files.module';
import { FileSchema } from './files/schema/file.schema';
import { MulterModule } from '@nestjs/platform-express';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { join } from 'path';
import { ServeStaticModule } from '@nestjs/serve-static';
import { StaticContensModule } from './static-contents/static-contents.module';
import { StaticContentSchema } from './static-contents/schema/static-contents.schema';
import { CategoriesSchema } from './categories/schema/categories.schema';
import { CategoriesModule } from './categories/categories.module';
import * as mongoose from 'mongoose';
import { ElementSchema } from './elements/schema/elements.schema';
import { ElementsModule } from './elements/elements.module';
import { AttributeSchema } from './attributes/schema/attributes.schema';
import { AttributesModule } from './attributes/attributes.module';
import { ProductsSchema } from './products/schema/products.schema';
import { ProductsModule } from './products/products.module';
import { MessageModule } from './messages/message.module';
import { OrdersModule } from './orders/order.module';
import { OrderSchema } from './orders/schema/order.schema';
import { MessageSchema } from './messages/schema/message.schema';
import { TasksModule } from './tasks/tasks.module';
import { ScheduleModule } from '@nestjs/schedule';
import { RelationSchema } from './tasks/schema/relation.schema';
import { OrderLogSchema } from './logs-order/schema/order-log.schema';
import { LogOrdersModule } from './logs-order/log-order.module';

const PATH_OPTIONS = {
  pathSeparator: '#', // String used to separate ids in path
  onDelete: 'REPARENT', // 'REPARENT' or 'DELETE'
  idType: mongoose.Schema.Types.ObjectId, // Type used for model id
};

@Module({
  imports: [
    MongooseModule.forRoot(process.env.MONGODB_CONNECTION, {
      useCreateIndex: true,
      audoIndex: true,
      connectionFactory: (connection) => {
        UserSchema.plugin(require('mongoose-password-plugin'));
        UserSchema.plugin(require('mongoose-paginate-v2'));
        FileSchema.plugin(require('mongoose-paginate-v2'));
        StaticContentSchema.plugin(require('mongoose-paginate-v2'));
        ElementSchema.plugin(require('mongoose-paginate-v2'));
        AttributeSchema.plugin(require('mongoose-paginate-v2'));
        ProductsSchema.plugin(require('mongoose-paginate-v2'));
        OrderSchema.plugin(require('mongoose-paginate-v2'));
        OrderLogSchema.plugin(require('mongoose-paginate-v2'));
        MessageSchema.plugin(require('mongoose-paginate-v2'));
        CategoriesSchema.plugin(require('mongoose-paginate-v2'));
        RelationSchema.plugin(require('mongoose-paginate-v2'));
        CategoriesSchema.plugin(require('mongoose-mpath'), PATH_OPTIONS);
        // Elimino sempre la password dagli utenti.
        UserSchema.methods.toJSON = function () {
          let obj: any = this.toObject();
          delete obj.password;
          return obj;
        };

        return connection;
      },
    }),
    UsersModule,
    AuthModule,
    FilesModule,
    StaticContensModule,
    ElementsModule,
    CategoriesModule,
    AttributesModule,
    ProductsModule,
    MessageModule,
    OrdersModule,
    LogOrdersModule,

    ConfigModule.forRoot({
      isGlobal: true,
    }),

    MulterModule.register(),

    ServeStaticModule.forRoot({
      rootPath: process.env.STATIC_PATH || join(__dirname, '..', 'public'),
    }),

    ScheduleModule.forRoot(),
    TasksModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
