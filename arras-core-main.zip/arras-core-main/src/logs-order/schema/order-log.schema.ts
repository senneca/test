import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { User } from 'src/users/schema/user.schema';
import { Orders } from 'src/orders/schema/order.schema';

export type OrderLogsDocument = OrderLogs & Document;

@Schema({ timestamps: true })
export class OrderLogs {

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: User.name })
  user: User;

  @Prop({ required: true })
  date: Date;

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: Orders.name })
  orderRef: Orders;

  @Prop({ required: true })
  order: string;
}

export const OrderLogSchema = SchemaFactory.createForClass(OrderLogs);
