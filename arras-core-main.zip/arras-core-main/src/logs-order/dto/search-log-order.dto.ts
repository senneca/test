import { IsDateString, IsEnum, IsOptional, IsString } from 'class-validator';

export class SearchLogOrderDTO {
  @IsOptional()
  @IsEnum(['asc', 'desc'])
  user: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByUser: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  date: 'asc' | 'desc';

  @IsOptional()
  @IsDateString()
  filterByDate: Date;

  @IsOptional()
  @IsString()
  filterByJson: string;

  @IsOptional()
  @IsString()
  orderId: string;

}
