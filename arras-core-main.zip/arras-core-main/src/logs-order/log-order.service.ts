import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { User, UserDocument } from 'src/users/schema/user.schema';

import { OrderLogs, OrderLogsDocument } from '../logs-order/schema/order-log.schema';

@Injectable()
export class LogOrdersService {
  constructor(
    @InjectModel(OrderLogs.name)
    private logOrdersModel: PaginateModel<OrderLogsDocument>,
    @InjectModel(User.name)
    private userModel: PaginateModel<UserDocument>,
  ) {}

  async findLogOrders(
    pi: number,
    ps: number,
    user,
    filterByUser,
    date,
    filterByDate,
    filterByJson,
    orderId) {

    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if (filterByUser) {
      const u = await this.userModel.find({
        email: { $regex: '.*' + filterByUser + '.*' },
      });
      if (u && u.length > 0) {
        query.user = { $in: u instanceof Array ? u : [u] };
      } else {
        query.user = { $in: [] };
      }
    }
    if (filterByDate) {
      query.date = { $eq: filterByDate };
    }

    if(filterByJson){
      query.order = {$regex: '.*' + filterByJson + '.*', $options: 'i'}
    }

    if(orderId){
      query.orderRef = orderId;
    }
    
    // Occorre sempre ordinare anche per chiave primaria o unica.
    if (user) {
      options.sort = { user };
    } else if (date) {
      options.sort = { date, user: 'asc' };
    } else {
      options.sort = { date: 'desc' };
    }

    options.populate = ['user'];

    return this.logOrdersModel.paginate(query, options);
  }
}