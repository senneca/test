import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { User, UserSchema } from 'src/users/schema/user.schema';
import { OrderLogs, OrderLogSchema } from '../logs-order/schema/order-log.schema';
import { LogOrdersController } from './log-order.controller';
import { LogOrdersService } from './log-order.service';

@Module({
  imports: [
    MongooseModule.forFeature([
        { name: OrderLogs.name, schema: OrderLogSchema },
        { name: User.name, schema: UserSchema },
    ])
  ],
  controllers: [LogOrdersController],
  providers: [LogOrdersService],
  exports: [LogOrdersService],
})
export class LogOrdersModule {}