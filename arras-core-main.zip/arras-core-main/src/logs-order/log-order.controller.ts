import {
    Controller,
    DefaultValuePipe,
    Get,
    Injectable,
    ParseIntPipe,
    Query,
    UseGuards,
  } from '@nestjs/common';
  import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
  import { Roles } from 'src/decorators/roles.decorator';
  import { Role } from 'src/enums/role.enum';
  import { RolesGuard } from 'src/guards/roles.guard';
  import { SearchLogOrderDTO } from '../logs-order/dto/search-log-order.dto';
import { LogOrdersService } from './log-order.service';
  

@Injectable()
@Controller('order')
export class LogOrdersController {
  constructor(private readonly ordersService: LogOrdersService) {}

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('logs/all')
  findLogOrders(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchLogOrderDTO,
  ) {
    return this.ordersService.findLogOrders(
      pi,
      ps,
      params.user,
      params.filterByUser,
      params.date,
      params.filterByDate,
      params.filterByJson,
      params.orderId
    );
  }

}