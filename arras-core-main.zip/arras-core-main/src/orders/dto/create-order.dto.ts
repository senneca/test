import {
  IsArray,
  IsBoolean,
  IsBooleanString,
  IsDateString,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';
import { ObjectId } from 'mongoose';
import { OrderStatus } from 'src/enums/orderStatus.enum';

export class CreateOrdersDTO {
  @IsNotEmpty()
  @IsString()
  productAlias: string;

  @IsOptional()
  @IsString()
  product: string;

  @IsOptional()
  @IsNumber()
  adults: number;

  @IsOptional()
  @IsNumber()
  children: number;

  @IsOptional()
  @IsString()
  type: string;

  // Città
  @IsOptional()
  @IsString()
  city: string;

  // City
  @IsOptional()
  @IsBoolean()
  checkout: boolean;

  // Prezzo finale
  @IsOptional()
  @IsNumber()
  finalPrice: number;

  @IsOptional()
  @IsDateString()
  from: Date;

  @IsOptional()
  @IsDateString()
  to: Date;

  @IsOptional()
  @IsArray()
  extras: Array<ObjectId>;

  @IsOptional()
  @IsEnum(OrderStatus)
  status: OrderStatus;
}
