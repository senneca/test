import { IsEnum, IsOptional, IsString } from 'class-validator';

export class SearchOrderDTO {
  @IsOptional()
  @IsEnum(['asc', 'desc'])
  user: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByUser: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  from: 'asc' | 'desc';

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  to: 'asc' | 'desc';

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  type: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByType: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  createdAt: 'asc' | 'desc';

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  status: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByStatus: string;

}
