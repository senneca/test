import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import {
  OrderLogs,
  OrderLogsDocument,
} from 'src/logs-order/schema/order-log.schema';
import {
  Products,
  ProductsDocument,
} from 'src/products/schema/products.schema';
import { User, UserDocument } from 'src/users/schema/user.schema';
import { CreateOrdersDTO } from './dto/create-order.dto';
import { EditOrderDto } from './dto/edit-order.dto';
import { Orders, OrdersDocument } from './schema/order.schema';

@Injectable()
export class OrdersService {
  constructor(
    @InjectModel(Orders.name)
    private ordersModel: PaginateModel<OrdersDocument>,
    @InjectModel(Products.name)
    private productsModel: PaginateModel<ProductsDocument>,
    @InjectModel(User.name)
    private userModel: PaginateModel<UserDocument>,
    @InjectModel(OrderLogs.name)
    private logModel: PaginateModel<OrderLogsDocument>,
  ) {}

  async create(user, createOrdersDto: CreateOrdersDTO): Promise<Orders> {
    const prod = await this.productsModel
      .findOne({ alias: createOrdersDto.productAlias })
      .exec();

    const u = await this.userModel.findOne({ email: user.email }).exec();

    if (prod && u) {
      createOrdersDto.product = prod._id;
      delete createOrdersDto.productAlias;

      const createdOrders = new this.ordersModel({
        ...createOrdersDto,
        user: u._id,
      });

      return createdOrders.save().then(x => {
        const logOrder = new this.logModel({
          user: u._id,
          date: new Date(),
          orderRef: x._id,
          order: JSON.stringify(createOrdersDto),
        });
        logOrder.save();
      });
    } else {
      throw new NotFoundException('Product or User not found');
    }
  }

  async findUserOrders(pi: number, ps: number, user) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    const u = await this.userModel.find({
      email: user.email,
    });

    if (!u || u.length !== 1) {
      throw new NotFoundException('User not found');
    }

    query.user = u;
    query.checkout = true;
    options.populate = ['product', 'extras'];

    return this.ordersModel.paginate(query, options);
  }

  async findOrders(
    pi: number,
    ps: number,
    user,
    filterByUser,
    from,
    to,
    type,
    filterByType,
    createdAt,
    status,
    filterByStatus,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if (filterByUser) {
      const u = await this.userModel.find({
        email: { $regex: '.*' + filterByUser + '.*' },
      });
      if (u && u.length > 0) {
        query.user = { $in: u instanceof Array ? u : [u] };
      } else {
        query.user = { $in: [] };
      }
    }
    if (filterByType) {
      query.type = { $regex: '.*' + filterByType + '.*' };
    }
    if (filterByStatus) {
      query.status = { $regex: '.*' + filterByStatus + '.*' };
    }

    // Occorre sempre ordinare anche per chiave primaria o unica.
    if (user) {
      options.sort = { user };
    } else if (from) {
      options.sort = { from, user: 'asc' };
    } else if (to) {
      options.sort = { to, user: 'asc' };
    } else if (type) {
      options.sort = { type, user: 'asc' };
    } else if (createdAt) {
      options.sort = { createdAt, user: 'asc' };
    } else if (status) {
      options.sort = { status, user: 'asc' };
    }

    options.populate = ['user', 'product', 'extras'];

    return this.ordersModel.paginate(query, options);
  }

  findOrderByID(id: string) {
    return this.ordersModel
      .findById(id)
      .populate('extras')
      .populate('product')
      .exec();
  }

  async updateOrder(id: string, dto: EditOrderDto, user) {
    const order = await this.ordersModel.findById(id);
    order.set(dto);
    
    return order.save().then(async x => {

      const u = await this.userModel.findOne({ email: user.email }).exec();
      if (u) {
        const logOrder = new this.logModel({
          user: u._id,
          date: new Date(),
          orderRef: x._id,
          order: JSON.stringify(dto),
        });
  
        logOrder.save();
      }
     

    });
  }

  deleteOrder(id: string) {
    return this.ordersModel.findByIdAndDelete(id);
  }
}
