import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { OrderLogs, OrderLogSchema } from 'src/logs-order/schema/order-log.schema';
import { Products, ProductsSchema } from 'src/products/schema/products.schema';
import { User, UserSchema } from 'src/users/schema/user.schema';
import { OrdersController } from './order.controller';
import { OrdersService } from './order.service';
import { Orders, OrderSchema } from './schema/order.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Orders.name, schema: OrderSchema },
      { name: Products.name, schema: ProductsSchema },
      { name: User.name, schema: UserSchema },
      { name: OrderLogs.name, schema: OrderLogSchema },
    ])
  ],
  controllers: [OrdersController],
  providers: [OrdersService],
  exports: [OrdersService],
})
export class OrdersModule {}
