import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { Attribute } from 'src/attributes/schema/attributes.schema';
import { User } from 'src/users/schema/user.schema';
import { Products } from 'src/products/schema/products.schema';
import { OrderStatus } from 'src/enums/orderStatus.enum';

export type OrdersDocument = Orders & Document;

@Schema({ timestamps: true })
export class Orders {
  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: User.name })
  user: User;

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: Products.name })
  product: Products;

  @Prop({ required: false })
  adults: number;

  @Prop({ required: false })
  children: number;

  // Città
  @Prop({ required: false })
  city: string;

  // City
  @Prop({ required: false })
  checkout: boolean;

  // Prezzo finale
  @Prop({ required: false })
  finalPrice: number;

  // Tipologia di cabina selezionata
  @Prop({ required: false })
  type: string;

  // Periodo da ..a..
  @Prop({ type: Date, required: false })
  from: Date;

  @Prop({ type: Date, required: false })
  to: Date;

  @Prop({
    type: [{ type: mongoose.Schema.Types.ObjectId, ref: Attribute.name }],
  })
  extras: Attribute[];

  @Prop({ required: false })
  note: string;

  @Prop({ required: true, enum:[OrderStatus.INVIATO, OrderStatus.IN_PAGAMENTO, OrderStatus.PAGATO, OrderStatus.ANNULLATO], default: OrderStatus.IN_PAGAMENTO })
  status: OrderStatus;
}

export const OrderSchema = SchemaFactory.createForClass(Orders);
