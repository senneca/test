import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { CreateOrdersDTO } from './dto/create-order.dto';
import { EditOrderDto } from './dto/edit-order.dto';
import { SearchOrderDTO } from './dto/search-order.dto';
import { OrdersService } from './order.service';

@Injectable()
@Controller('order')
export class OrdersController {
  constructor(private readonly ordersService: OrdersService) {}

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() ordersDto: CreateOrdersDTO, @Req() request) {
    return this.ordersService.create(request.user, ordersDto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('ORDER_EXISTS');
      }
      throw err;
    });
  }

  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('me')
  getUserOrders(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Req() request,
  ) {
    return this.ordersService.findUserOrders(
      pi,
      ps,
      request.user
    );
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllOrders(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchOrderDTO,
  ) {
    return this.ordersService.findOrders(
      pi,
      ps,
      params.user,
      params.filterByUser,
      params.from,
      params.to,
      params.type,
      params.filterByType,
      params.createdAt,
      params.status,
      params.filterByStatus
    );
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findOrderById(@Param('id') id: string) {
    return this.ordersService.findOrderByID(id).catch((err) => {
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editOrder(@Param('id') id: string, @Body() dto: EditOrderDto, @Req() request?) {
    return this.ordersService.updateOrder(id, dto, request.user).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_ORDER');
      } else {
        throw new NotFoundException('ORDER_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeOrder(@Param('id') id: string) {
    return this.ordersService.deleteOrder(id).catch((err) => {
      if (err) {
        throw new NotFoundException('ORDER_NOT_FOUND');
      }
      throw err;
    });
  }
}
