import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import * as mongoose from 'mongoose';
import { AttributesService } from './attributes.service';
import { CreateAttributeDto } from './dto/create-attribute.dto';
import { SearchAttributesDto } from './dto/search-attribute.dto';
import { EditAttributeDto } from './dto/edit-attribute.dto';
import { EditOrderAttributeDto } from './dto/edit-order-attribute';

@Injectable()
@Controller('attributes')
export class AttributesController {
  constructor(private readonly attributeService: AttributesService) {}

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createAttributeDto: CreateAttributeDto) {
    return this.attributeService.create(createAttributeDto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('ATTRIBUTE_EXISTS');
      } else throw new BadRequestException('GENERIC_ERROR');
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllAttributes(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchAttributesDto,
  ) {
    return this.attributeService.findAllAttributes(
      pi,
      ps,
      params.typology,
      params.filterByValue,
      params.filterByReference,
    );
  }

  @Get('list')
  findAllAttributesPublic(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchAttributesDto,
  ) {
    return this.attributeService.findAllAttributes(
      pi,
      ps,
      params.typology,
      params.filterByValue,
      params.filterByReference,
    );
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findAttribute(@Param('id') id: string) {
    return this.attributeService.findOneAttributeById(id).catch((err) => {
      if (err) {
        throw new NotFoundException('ATTRIBUTE_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editAttribute(@Param('id') id: string, @Body() dto: EditAttributeDto) {
    return this.attributeService.updateAttribute(id, dto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_TITLE_ATTRIBUTE');
      } else {
        throw new NotFoundException('ATTRIBUTE_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch()
  editOrderAttribute(@Body() dto: Array<EditOrderAttributeDto>) {
    return this.attributeService.updateOrderAttribute(dto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_TITLE_ATTRIBUTE');
      } else {
        throw new NotFoundException('ATTRIBUTE_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeAttribute(@Param('id') id: string) {
    return this.attributeService.deleteAttribute(id).catch((err) => {
      if (err) {
        throw new NotFoundException('ATTRIBUTE_NOT_FOUND');
      }
      throw err;
    });
  }
}
