import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { Typology } from 'src/enums/typology.enum';
import { CreateAttributeDto } from './dto/create-attribute.dto';
import { EditAttributeDto } from './dto/edit-attribute.dto';
import { EditOrderAttributeDto } from './dto/edit-order-attribute';
import { Attribute, AttributeDocument } from './schema/attributes.schema';

@Injectable()
export class AttributesService {
  constructor(
    @InjectModel(Attribute.name)
    private attributeModel: PaginateModel<AttributeDocument>,
  ) {}

  async create(
    createAttributeDto: CreateAttributeDto): Promise<Attribute> {
    
    const createdAttribute = new this.attributeModel(createAttributeDto);
    return createdAttribute.save();
  }

  findAllAttributes(
    pi: number,
    ps: number,
    typology: string,
    filterByValue: string,
    filterByRefence: string
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if(typology){ 
      query.typology = { $regex: '.*' +typology + '.*'};
    }

    if(filterByValue){
      query.value = { $regex: filterByValue};
    }

    if(filterByRefence){
      query.reference = { $regex: filterByRefence};
    }
  
    options.populate = 'element';
    options.sort = {order: 0};

    return this.attributeModel.paginate(query, options);
  }

  findOneAttributeById(id: string) {
    return this.attributeModel
      .findById(id)
      .populate('element')
      .exec();
  }

  async updateAttribute(id: string, dto: EditAttributeDto) {
    const attribute= await this.attributeModel.findById(id);
    attribute.set(dto);

    return attribute.save();
  }

  async updateOrderAttribute(dto: Array<EditOrderAttributeDto>) {
    dto.forEach(async elem => {
      const value = await this.attributeModel.findById(elem.id);
      value.order = elem.order;
      value.save();
    });
  }


  deleteAttribute(id: string) {
    return this.attributeModel.findByIdAndDelete(id);
  }

}
