import {
    IsNotEmpty,
    IsNumber,
    IsString,
  } from 'class-validator';
  
  export class EditOrderAttributeDto {

    @IsNotEmpty()
    @IsString()
    id: string;
  
    @IsNotEmpty()
    @IsNumber()
    order: number;
    
  }
  