import {
    IsArray,
  IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { Typology } from 'src/enums/typology.enum';
  
  export class EditAttributeDto {

    @IsOptional()
    @IsNumber()
    order: number;
  
    @IsOptional()
    @IsString()
    @MinLength(2)
    name: string;

    @IsOptional()
    @IsString()
    value: string;
    
    @IsOptional()
    @IsString()
    reference: string;

    @IsOptional()
    @IsString()
    element: ObjectId;
  }
  