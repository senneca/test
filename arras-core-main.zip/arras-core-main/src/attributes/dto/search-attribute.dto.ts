import { IsEnum, IsOptional, IsString } from "class-validator";

export class SearchAttributesDto {

    @IsOptional()
    @IsString()
    filterByValue: string;

    @IsOptional()
    @IsString()
    filterByReference: string;

    @IsOptional()
    @IsString()
    typology: string;
    
}