import {
    IsArray,
    IsBoolean,
    IsEnum,
    IsNotEmpty,
    IsNumber,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { Typology } from 'src/enums/typology.enum';
  
  export class CreateAttributeDto {
   
    @IsNotEmpty()
    @IsEnum(Typology)
    typology: Typology;

    @IsNotEmpty()
    @IsNumber()
    order: number;
  
    @IsNotEmpty()
    @IsString()
    @MinLength(2)
    name: string;

    @IsOptional()
    @IsString()
    value: string;
    
    @IsOptional()
    @IsString()
    reference: string;
    

    @IsOptional()
    @IsString()
    element?: ObjectId;

  }
  