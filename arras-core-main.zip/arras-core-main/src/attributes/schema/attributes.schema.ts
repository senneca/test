import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { Document } from 'mongoose';
import { Element } from 'src/elements/schema/elements.schema';
import { Typology } from 'src/enums/typology.enum';

export type AttributeDocument = Attribute & Document;

@Schema({ timestamps: true})
export class Attribute {

  @Prop({ required: true, enum:[Typology.Cities, Typology.Extras, Typology.Ships, Typology.Companies, Typology.Cabins]})
  typology: Typology;

  @Prop({ required: true})
  order: number;

  @Prop({ required: true, unique: true })
  name: string;

  @Prop({ required: false})
  value: string;

  @Prop({ required: false})
  reference: string;

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: Element.name }] })
  element: Element;
 
}

export const AttributeSchema = SchemaFactory.createForClass(Attribute);
