export enum Role {
    User = 'user',
    Editor = 'editor',
    Admin = 'admin',
  }