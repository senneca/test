export enum OrderStatus {
    INVIATO = 'Inviato',
    IN_PAGAMENTO= 'In Pagamento',
    PAGATO = 'Pagato', 
    ANNULLATO= 'Annullato'
  }