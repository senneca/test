export enum Typology {
    Cities = 'cities',
    Extras = 'extras',
    Ships = 'ships',
    Companies = 'companies',
    Cabins = 'cabins'
  }