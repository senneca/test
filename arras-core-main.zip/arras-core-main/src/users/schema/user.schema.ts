import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Role } from '../../enums/role.enum';

export type UserDocument = User & Document;

@Schema({timestamps: true})
export class User {
    @Prop({ required: true, unique: true })
    email: string;

    @Prop({ required: true })
    password: string;
    
    @Prop({ required: true, enum:[Role.User, Role.Editor, Role.Admin], default: Role.User })
    role: Role;

    @Prop({ required: false, minLength: 2 })
    firstName: string;

    @Prop({ required: false, minLength: 2 })
    lastName: string;

    @Prop({ required: false})
    phone: string;
}

export const UserSchema = SchemaFactory.createForClass(User);