import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
  NotFoundException,
  BadRequestException,
  Query,
  ParseIntPipe,
  DefaultValuePipe,
  Req
} from '@nestjs/common';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { SignUpUserDto } from './dto/signup-user.dto';
import { SearchUserDto } from './dto/search-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User, UserDocument } from './schema/user.schema';
import { GetResponseService } from 'src/services/getresponse.service';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Controller('users')
export class UsersController {
  constructor(
    private usersService: UsersService,
    private getResponseService: GetResponseService,
  ) {}

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.usersService
      .create(createUserDto)
      .then((user: User) => {
        this.getResponseService.update(user);
        return user;
      })
      .catch((err) => {
        if (err.code === 11000) {
          throw new BadRequestException('EMAIL_EXISTS');
        }
        throw err;
      });
  }

  @Post('sign-up')
  signUp(@Body() dto: SignUpUserDto) {
    return this.usersService
      .create({
        ...dto,
        role: Role.User,
      })
      .then((user: User) => {
        this.getResponseService.update(user);
        return user;
      })
      .catch((err) => {
        if (err.code === 11000) {
          throw new BadRequestException('EMAIL_EXISTS');
        }
        throw err;
      });
  }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAll(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchUserDto,
  ) {
    return this.usersService.findAll(
      pi,
      ps,
      params.email,
      params.filterByEmail,
      params.role,
      params.filterByRole,
    );
  }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  myProfile(@Req() request) {
    return this.usersService.findOneByEmail(request.user.email).then((u) => {
      if (!u) {
        throw new NotFoundException();
      }
      return u;
    });
  }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.usersService.findOne(id).then((u) => {
      if (!u) {
        throw new NotFoundException();
      }
      return u;
    });
  }

  @UseGuards(JwtAuthGuard)
  @Patch('me')
  updateMyProfile(@Body() dto: UpdateProfileDto, @Req() request) {
    return this.usersService.findOneByEmail(request.user.email).then((u: UserDocument) => {
      if (!u) {
        throw new NotFoundException();
      }
      return this.usersService.update(u._id, dto).then((user) => {
        this.getResponseService.update(user);

        return user;
      });
    });
  }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateUserDto) {
    return this.usersService.update(id, dto).then((user) => {
      this.getResponseService.update(user);

      return user;
    });
  }

  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.usersService.remove(id).then((u) => {
      if (!u) {
        throw new NotFoundException();
      }
      return u;
    });
  }
}
