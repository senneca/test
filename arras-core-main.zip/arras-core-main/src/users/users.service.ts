import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User, UserDocument } from './schema/user.schema';

@Injectable()
export class UsersService {
  constructor(
    @InjectModel(User.name) private userModel: PaginateModel<UserDocument>,
  ) {}

  create(createUserDto: CreateUserDto): Promise<User> {
    const createdUser = new this.userModel(createUserDto);
    return createdUser.save();
  }

  findAll(pi: number, ps: number, email, filterByEmail, role, filterByRole) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};
    if (filterByEmail) {
      query.email = { $regex: '.*' + filterByEmail + '.*' };
    }
    if (filterByRole) {
      query.role = { $regex: '.*' + filterByRole + '.*' };
    }
    if (email) {
      options.sort = { email };
    } else if (role) {
      options.sort = { role };
    }

    return this.userModel.paginate(query, options);
  }

  findOne(id: string) {
    return this.userModel.findById(id);
  }

  findOneByEmail(email: string): Promise<User> {
    return this.userModel.findOne({ email }).exec();
  }

  async update(id: string, dto: UpdateUserDto | UpdateProfileDto) {
    const user = await this.userModel.findById(id);
    user.set(dto);

    return user.save();
  }

  remove(id: string) {
    return this.userModel.findByIdAndDelete(id);
  }
}
