import {IsEnum, IsOptional, IsString } from 'class-validator';

export class SearchUserDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    email: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByEmail: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    role: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByRole: string;
}
