import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { Element, ElementDocument } from 'src/elements/schema/elements.schema';
import { CreateStaticPageDto } from './dto/create-static-page.dto';
import { EditStaticPageDto } from './dto/edit-static-page.dto';
import {
  StaticContent,
  StaticContentDocument,
} from './schema/static-contents.schema';

@Injectable()
export class StaticContentsService {
  constructor(
    @InjectModel(StaticContent.name)
    private staticContentModel: PaginateModel<StaticContentDocument>,
    @InjectModel(Element.name)
    private elementModel: PaginateModel<ElementDocument>,
  ) {}

  async create(
    createStaticPageDto: CreateStaticPageDto,
    author: string,
  ): Promise<StaticContent> {
    if (author && author !== '') {
      createStaticPageDto.author = author;
    }
    const createdStaticPage = new this.staticContentModel(createStaticPageDto);
    return createdStaticPage.save();
  }

  findAllStaticPages(
    pi: number,
    ps: number,
    title,
    filterByTitle,
    alias,
    filterByAlias,
    category,
    filterByCategory,
    page,
    filterByPage,
    author,
    filterByAuthor,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};
    if (filterByTitle) {
      query.title = { $regex: '.*' + filterByTitle + '.*' };
    }
    if (filterByAlias) {
      query.alias = { $regex: '.*' + filterByAlias + '.*' };
    }
    if (filterByCategory && filterByCategory !== 'null') {
      query.categories = { _id: filterByCategory};
    }
    if (filterByPage && filterByPage !== 'null') {
      query.staticPage = { _id: filterByPage };
    }
    if (filterByAuthor) {
      query.author = { $regex: '.*' + filterByAuthor + '.*' };
    }

    if (title) {
      options.sort = { title };
    } else if (alias) {
      options.sort = { alias };
    } else if (author) {
      options.sort = { author };
    }
    options.populate = ['files', 'categories', 'seo.snippetFacebook.image', 'wireframe'];

    return this.staticContentModel.paginate(query,options);
  }

  findOnePageById(id: string) {
    return this.staticContentModel
      .findById(id)
      .populate('files')
      .populate('categories')
      .populate('wireframe')
      .exec();
  }

  async findPagesByAlias(alias: string): Promise<StaticContent> {
    return await this.staticContentModel
      .findOne({ alias: alias, published: true })
      .populate('files')
      .populate('categories')
      .populate({path: 'seo.snippetFacebook.image'})
      .populate('wireframe')
      .exec();
  }

  async findPagesByCategory(category: string): Promise<Array<StaticContent>> {
    return await this.staticContentModel
      .find({ categories: category, published: true })
      .populate('files')
      .populate('categories')
      .populate('wireframe')
      .exec();
  }

  async filterByCategory(id: string): Promise<Array<StaticContent>> {
    let array = [];
    array.push(id);
    return await this.staticContentModel
      .find({categories: { $in: array}})
      .populate('files')
      .populate('categories')
      .exec();
  }

  async updateStaticPage(id: string, dto: EditStaticPageDto, author) {
    if (author && author !== '') {
      dto.author = author;
    }
    return this.staticContentModel.findByIdAndUpdate(id, dto, {
      new: true,
      useFindAndModify: false,
    });
  }

  deleteStaticPage(id: string) {
    return this.staticContentModel.findByIdAndDelete(id);
  }

  updateStatePage(id: string, state: any) {
    return this.staticContentModel.findByIdAndUpdate(id, {
      published: state.value,
    });
  }

  async findPositionsById(id: string) {
    const values = await this.staticContentModel.findById(id);
    return {positions: values.positions};
  }

  async findElementsByAlias(pi: number, ps: number, position: string[], alias: string) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    const elements = await this.staticContentModel.find({alias: alias});
    if(elements && elements.length > 0){      
      if(position && position.length > 0){
        query.position = position;
      }
      
      query.staticPages = elements[0]._id,
      query.published = true,
      options.populate = ['files'];

     return await this.elementModel
     .paginate(query, options)
    } else return null;
  }
}
