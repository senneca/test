import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { CreateStaticPageDto } from './dto/create-static-page.dto';
import { EditStaticPageDto } from './dto/edit-static-page.dto';
import { SearchStaticPagesDto } from './dto/search-static-pages.dto';
import { StaticContentsService } from './static-contents.service';
import * as mongoose from 'mongoose';


@Injectable()
@Controller('static-content')
export class StaticContentsController {
  
  constructor(private readonly staticContentService: StaticContentsService) {}

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Post()
  create(@Body() createStaticPageDto: CreateStaticPageDto, @Req() request) {
    return this.staticContentService
      .create(createStaticPageDto, request.user.email)
      .catch((err) => {
        if (err.code === 11000) {
          throw new BadRequestException('ALIAS_PAGE_EXISTS');
        } else if (err instanceof mongoose.Error.ValidationError){
          console.log(err);
          throw new BadRequestException('FILE_ID_OR_CATEGORY_ID_DOES_NOT_EXISTS');
        } else 
        throw new BadRequestException('GENERIC_ERROR');
      });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllStaticPages(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchStaticPagesDto){
    return this.staticContentService.findAllStaticPages(
      pi,
      ps,
      params.title,
      params.filterByTitle,
      params.alias,
      params.filterByAlias,
      params.category,
      params.filterByCategory,
      params.page,
      params.filterByPage,
      params.author,
      params.filterByAuthor)
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findStaticPage(@Param('id') id: string){
    return this.staticContentService.findOnePageById(id).catch((err) => {
      if(err){
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
      throw err;
    });
  }  

  @Get('alias/:alias')
  findStaticPageByAlias(@Param('alias') alias: string){
    return this.staticContentService.findPagesByAlias(alias).then((file) => {
      if(!file){
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
      return file;
    });
  }  
 
  @Get('category/:category')
  findStaticPagesByCategories(@Param('category') category: string){
    return this.staticContentService.findPagesByCategory(category).then((file) => {
      if(!file){
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
      return file;
    });
  }

  @Get('filter/:id')
  filterByCategoriesList(@Param('id') id: string){
    return this.staticContentService.filterByCategory(id).then((file) => {
      if(!file){
        throw new NotFoundException('PAGE_CATEGORIES_NOT_FOUND');
      }
      return file;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editStaticPage(@Param('id') id: string, @Body() dto: EditStaticPageDto, @Req() request) {
    return this.staticContentService.updateStaticPage(id, dto, request.user.email).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_TITLE_PAGE');
      } else {
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeStaticPage(@Param('id') id: string) {
    return this.staticContentService.deleteStaticPage(id).catch((err) => {
      if (err) {
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch('page/:id')
  PublishPage(@Param('id') id: string, @Body() value: {value: boolean}) {
    return this.staticContentService.updateStatePage(id, value).catch((err) => {
      if (err) {
        throw new NotFoundException('PAGE_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('positions/:id')
  getStaticPagePositions(@Param('id') id: string) {
    return this.staticContentService.findPositionsById(id).catch((err) => {
      if (err) {
        throw new NotFoundException('POSITIONS_NOT_FOUND');
      }
      throw err;
    });
  }

  @Get('alias/:alias/elements')
  getAllElementsByAlias(@Param('alias') alias: string,  
  @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
  @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
  @Query('position') position: string[]){
    return this.staticContentService.findElementsByAlias(pi, ps, position, alias).catch((err) => {
      if (err) {
        throw new NotFoundException('ALIAS_NOT_FOUND');
      }
      throw err;
    });
  }

}
