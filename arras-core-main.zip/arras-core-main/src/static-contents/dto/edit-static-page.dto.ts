import {
    IsArray,
    IsNotEmpty,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { SeoDto } from './seo-content';
  
  export class EditStaticPageDto {

    @IsNotEmpty()
    @IsString()
    title: string;
  
    @IsOptional()
    @IsString()
    author: string;

    @IsNotEmpty()
    @IsString()
    @MinLength(3)
    alias: string;

    @IsOptional()
    @IsString()
    content: string;
  
    @IsOptional()
    @IsArray()
    files?: Array<ObjectId>;

    @IsOptional()
    @IsString()
    wireframe: ObjectId;
  
    @IsNotEmpty()
    @IsArray()
    categories?: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    tags?: Array<string>;

    @IsOptional()
    @IsArray()
    positions?: Array<string>;

    @IsNotEmpty()
    @IsObject()
    seo?: SeoDto;

    @IsOptional()
    @IsString()
    script: string;
  }
  