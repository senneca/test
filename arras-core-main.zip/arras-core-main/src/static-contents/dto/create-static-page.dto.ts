import {
    IsArray,
    IsBoolean,
    IsNotEmpty,
    IsObject,
    IsOptional,
    IsString,
    MinLength,
  } from 'class-validator';
import { ObjectId } from 'mongoose';
import { SeoDto } from './seo-content';
  
  export class CreateStaticPageDto {

    @IsNotEmpty()
    @IsString()
    title: string;
  
    @IsNotEmpty()
    @IsString()
    @MinLength(3)
    alias: string;

    @IsOptional()
    @IsString()
    content: string;

    @IsOptional()
    @IsBoolean()
    published: boolean;

    @IsOptional()
    @IsString()
    author: string;
  
    @IsOptional()
    @IsArray()
    files?: Array<ObjectId>;

    @IsOptional()
    @IsString()
    wireframe: ObjectId;
  
    @IsOptional()
    @IsArray()
    categories?: Array<ObjectId>;

    @IsOptional()
    @IsArray()
    tags?: Array<string>;

    @IsOptional()
    @IsArray()
    positions?: Array<string>;

    @IsNotEmpty()
    @IsObject()
    seo?: SeoDto;

    @IsOptional()
    @IsString()
    script: string;
  }
  