import { IsEnum, IsOptional, IsString } from "class-validator";

export class SearchStaticPagesDto {
    @IsOptional()
    @IsEnum(['asc', 'desc'])
    title: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByTitle: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    alias: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByAlias: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    category: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByCategory: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    page: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByPage: string;

    @IsOptional()
    @IsEnum(['asc', 'desc'])
    author: 'asc' | 'desc';

    @IsOptional()
    @IsString()
    filterByAuthor: string;
    
}