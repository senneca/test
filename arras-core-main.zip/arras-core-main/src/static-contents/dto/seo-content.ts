import { IsArray, IsEnum, IsNotEmpty, IsObject, IsOptional, IsString } from "class-validator";
import { SeoFBDto } from "./seo-fb.dto";
import { SeoGoogleDto } from "./seo-google.dto";

export class SeoDto {
    @IsNotEmpty()
    @IsString()
    title: string;

    @IsNotEmpty()
    @IsObject()
    keywords?: any;

    @IsOptional()
    @IsObject()
    snippetFacebook: SeoFBDto;

    @IsOptional()
    @IsObject()
    snippetGoogle: SeoGoogleDto;
}