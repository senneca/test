import { Prop, raw, Schema, SchemaFactory } from '@nestjs/mongoose';
import * as mongoose from 'mongoose';
import { Document } from 'mongoose';
import { Categories } from 'src/categories/schema/categories.schema';
import { File } from 'src/files/schema/file.schema';

export type StaticContentDocument = StaticContent & Document;

@Schema({ timestamps: true})
export class StaticContent {

  @Prop({ required: true})
  title: string;

  @Prop({ required: true, unique: true })
  alias: string;

  @Prop({ required: false})
  content: string;

  @Prop({required: true, default: false})
  published: boolean;

  @Prop({required: true})
  author: string; 

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: Categories.name }] })
  categories: Categories[];

  @Prop({default: []})
  tags: Array<string>; 

  @Prop({default: []})
  positions: Array<string>; 

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }] })
  files: File[];

  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: File.name })
  wireframe: File;

  @Prop({required: false})
  script: string; 

  @Prop(raw({
    title: {type: String},
    description: {type: String},
    keywords: {type: Array<String>()},
    snippetFacebook: {
      title: {type: String},
      description: {type: String},
      image: {type: [{ type: mongoose.Schema.Types.ObjectId, ref: File.name }]}
    },
    snippetGoogle: {title: {type: String},
    description: {type: String}
  }}))
  seo: Record<string, any>;
 
}

export const StaticContentSchema = SchemaFactory.createForClass(StaticContent);
