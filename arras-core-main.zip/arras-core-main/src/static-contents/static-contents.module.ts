import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ElementsService } from 'src/elements/elements.service';
import { Element, ElementSchema } from 'src/elements/schema/elements.schema';
import {
  StaticContent,
  StaticContentSchema,
} from './schema/static-contents.schema';
import { StaticContentsController } from './static-contents.controller';
import { StaticContentsService } from './static-contents.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: StaticContent.name, schema: StaticContentSchema },
      { name: Element.name, schema: ElementSchema },
    ]),
  ],
  controllers: [StaticContentsController],
  providers: [StaticContentsService, ElementsService],
  exports: [StaticContentsService],
})
export class StaticContensModule {}
