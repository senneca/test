import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Products, ProductsSchema } from 'src/products/schema/products.schema';
import { Relation, RelationSchema } from './schema/relation.schema';
import { TasksService } from './tasks.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Products.name, schema: ProductsSchema },
      { name: Relation.name, schema: RelationSchema },
    ]),

  ],
  providers: [TasksService],
})
export class TasksModule {}
