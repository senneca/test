import { Injectable, Logger } from '@nestjs/common';
import { PaginateModel } from 'mongoose-paginate-v2';
import { Cron, Interval } from '@nestjs/schedule';
import {
  Products,
  ProductsDocument,
} from 'src/products/schema/products.schema';
import { InjectModel } from '@nestjs/mongoose';
import { Relation, RelationDocument } from './schema/relation.schema';
import { Model } from 'mongoose';
import { ConfigService } from '@nestjs/config';
const DecompressZip = require('decompress-zip');
const ClientSFTP = require('ssh2-sftp-client');
const sftp = new ClientSFTP();

@Injectable()
export class TasksService {
  constructor(
    @InjectModel(Products.name)
    private productModel: PaginateModel<ProductsDocument>,
    @InjectModel(Relation.name)
    private relationModel: Model<RelationDocument>,
    private readonly configService: ConfigService,
  ) {}
  private readonly logger = new Logger(TasksService.name);

  @Cron('0 0 3 * * *')
  async sftpDownloadMSCFiles() {
    //this.sftpClient.

    try {
      await sftp.connect({
        host: this.configService.get<string>('MSC_HOST'),
        port: 22,
        username: this.configService.get<string>('MSC_USER'),
        password: this.configService.get<string>('MSC_PASSWORD'),
      });

      await this.download('GBL', 'flatportdetl_ita.zip');
      await this.download('ITA', 'flatfile_ita_shpdetl_csv.zip');
      await this.download('ITA', 'flatfile_ita_air_csv.zip');
      await this.download('ITA', 'flatfile_ita_itinff_csv.zip');
    } catch (e) {
      this.logger.error(e);
    } finally {
      await sftp.end();
    }
  }

  download(mrk, file) {
    const MSC_BASEPATH = this.configService.get<string>('MSC_BASEPATH');
    const MSC_REMOTEPATH = '/DownloadArea/ONDEMAND/' + mrk + '/' + file;

    const dst = MSC_BASEPATH + file;
    this.logger.log('Download ' + MSC_REMOTEPATH);
    return sftp.fastGet(MSC_REMOTEPATH, dst).then(() => {
      var unzipper = new DecompressZip(dst);
      return unzipper.extract({ path: MSC_BASEPATH });
    });
  }

  // Calcolo i correlati ogni minuto.
  @Interval(60000)
  async calulateRelated() {
    const ids: string[] = (await this.relationModel.find()).map((doc: any) =>
      doc.product1.toString(),
    );
    const products = await this.productModel.find({ published: true });
    products.forEach((product: any) => {
      if (ids && ids.includes(product._id.toString())) {
        return;
      }
      products
        .filter((p) => product._id !== p._id)
        .forEach((p) => {
          const score = this.getRelationScore(product, p);
          const model = new this.relationModel({
            product1: product._id,
            product2: p._id,
            score: score,
          });
          model.save();
        });
    });
  }

  getRelationScore(el1: ProductsDocument, el2: ProductsDocument) {
    // @todo Data di partenza  10pt …per ogni settimana di slittamento viene sottratto 1 punto
    this.logger.log('Calculate ralation from ' + el1._id + ' to ' + el2._id);
    let score = 0;
    // Compagnia
    if (el1.company === el2.company) {
      score += 8;
      // this.logger.log('company ' + el2.company);
    }

    // Tags
    if (el1.tags) {
      el1.tags.forEach((t) => {
        if (el2.tags && el2.tags.includes(t)) {
          score += 4;
        }
        // this.logger.log('tags');
      });
    }
    // Porto di transito
    if (el1.route) {
      el1.route.forEach((r) => {
        let city = el2.route && el2.route.find((x) => x.alias === r.alias);
        if (city) {
          score += 1;
        }
        // this.logger.log('route');
      });
    }

    // Extra
    if (el1.extras) {
      el1.extras.forEach((e) => {
        if (el2.extras && el2.extras.includes(e)) {
          score += 0.5;
          // this.logger.log('extra');
        }
      });
    }

    return score;
  }
}
