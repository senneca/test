import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { Products } from 'src/products/schema/products.schema';

export type RelationDocument = Relation & Document;

@Schema({timestamps: true})
export class Relation {
  
    @Prop({ required: true, index: true, type: mongoose.Schema.Types.ObjectId, ref: Products.name })
    product1: Products;

    @Prop({ required: true, index: true, type: mongoose.Schema.Types.ObjectId, ref: Products.name })
    product2: Products;

    @Prop({ required: true })
    score: number;
}

export const RelationSchema = SchemaFactory.createForClass(Relation);
RelationSchema.index({ product1: 1, product2: 1 }, { unique: true });
