import { IsEnum, IsOptional, IsString } from 'class-validator';

export class SearchMessageDTO {
  @IsOptional()
  @IsEnum(['asc', 'desc'])
  firstName: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByFirstName: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  lastName: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByLastName: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  email: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByEmail: string;

  @IsOptional()
  @IsEnum(['asc', 'desc'])
  message: 'asc' | 'desc';

  @IsOptional()
  @IsString()
  filterByMessage: string;
}
