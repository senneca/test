import { IsOptional, IsString } from 'class-validator';

export class EditMessageDTO {
  @IsOptional()
  @IsString()
  note: string;
}
