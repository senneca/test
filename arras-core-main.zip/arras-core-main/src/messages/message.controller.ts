import {
  BadRequestException,
  Body,
  Controller,
  DefaultValuePipe,
  Delete,
  Get,
  Injectable,
  NotFoundException,
  Param,
  ParseIntPipe,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/jwt-auth.guard';
import { OptionalJwtAuthGuard } from 'src/auth/optional-jwt-auth.guard';
import { Roles } from 'src/decorators/roles.decorator';
import { Role } from 'src/enums/role.enum';
import { RolesGuard } from 'src/guards/roles.guard';
import { CreateMessageDTO } from './dto/create-message.dto';
import { EditMessageDTO } from './dto/edit-message.dto';
import { SearchMessageDTO } from './dto/search-message.dto';
import { MessageService } from './message.service';

@Injectable()
@Controller('message')
export class MessageController {
  constructor(private readonly messageService: MessageService) {}

  @UseGuards(OptionalJwtAuthGuard)
  @Post()
  create(@Body() messageDto: CreateMessageDTO, @Req() request) {
    return this.messageService.create(messageDto, request.user).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('MESSAGE_EXISTS');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get()
  findAllMessages(
    @Query('pi', new DefaultValuePipe(1), ParseIntPipe) pi: number,
    @Query('ps', new DefaultValuePipe(50), ParseIntPipe) ps: number,
    @Query() params: SearchMessageDTO,
  ) {
    return this.messageService.findMessages(
      pi,
      ps,
      params.firstName,
      params.filterByFirstName,
      params.lastName,
      params.filterByLastName,
      params.email,
      params.filterByEmail,
      params.message,
      params.filterByMessage,
    );
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get(':id')
  findMessageById(@Param('id') id: string) {
    return this.messageService.findMessageByID(id).catch((err) => {
      if (err) {
        throw new NotFoundException('MESSAGE_NOT_FOUND');
      }
      throw err;
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Patch(':id')
  editMessage(@Param('id') id: string, @Body() dto: EditMessageDTO) {
    return this.messageService.updateMessage(id, dto).catch((err) => {
      if (err.code === 11000) {
        throw new BadRequestException('DUPLICATE_MESSAGE');
      } else {
        throw new NotFoundException('MESSAGE_NOT_FOUND');
      }
    });
  }

  @Roles(Role.Admin, Role.Editor)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Delete(':id')
  removeMessage(@Param('id') id: string) {
    return this.messageService.deleteMessage(id).catch((err) => {
      if (err) {
        throw new NotFoundException('MESSAGE_NOT_FOUND');
      }
      throw err;
    });
  }
}
