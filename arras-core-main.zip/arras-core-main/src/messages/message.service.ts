import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { PaginateModel } from 'mongoose-paginate-v2';
import { Role } from 'src/enums/role.enum';
import { User, UserDocument } from 'src/users/schema/user.schema';
import { CreateMessageDTO } from './dto/create-message.dto';
import { EditMessageDTO } from './dto/edit-message.dto';
import { Message, MessageDocument } from './schema/message.schema';

@Injectable()
export class MessageService {
  constructor(
    @InjectModel(Message.name)
    private messageModel: PaginateModel<MessageDocument>,
    @InjectModel(User.name) private userModel: PaginateModel<UserDocument>,
  ) {}

  async create(createMessageDto: CreateMessageDTO, u: any): Promise<Message> {
    let user = null;
    if (u) {
      user = await this.userModel.findOne({ email: u.email });
    }
    const createdMessage = new this.messageModel({
      ...createMessageDto,
      user: user ? user._id : null,
    });
    return createdMessage.save();
  }

  findMessages(
    pi: number,
    ps: number,
    firstName,
    filterByFirstName,
    lastName,
    filterByLastName,
    email,
    filterByEmail,
    message,
    filterByMessage,
  ) {
    let options: any = { page: pi, limit: ps };
    let query: any = {};

    if (filterByFirstName) {
      query.firstName = { $regex: '.*' + filterByFirstName + '.*' };
    }
    if (filterByLastName) {
      query.lastName = { $regex: '.*' + filterByLastName + '.*' };
    }
    if (filterByEmail) {
      query.email = { $regex: '.*' + filterByEmail + '.*' };
    }
    if (filterByMessage) {
      query.message = { $regex: '.*' + filterByMessage + '.*' };
    }

    if (firstName) {
      options.sort = { firstName, email: 'asc' };
    } else if (lastName) {
      options.sort = { lastName, email: 'asc' };
    } else if (email) {
      options.sort = { email };
    } else if (message) {
      options.sort = { message, email: 'asc' };
    }

    options.populate = ['user'];

    return this.messageModel.paginate(query, options);
  }

  findMessageByID(id: string) {
    return this.messageModel
      .findById(id)
      .populate('extras')
      .populate('product')
      .exec();
  }

  async updateMessage(id: string, dto: EditMessageDTO) {
    const message = await this.messageModel.findById(id);
    message.set({ note: dto.note });

    return message.save();
  }

  deleteMessage(id: string) {
    return this.messageModel.findByIdAndDelete(id);
  }
}
