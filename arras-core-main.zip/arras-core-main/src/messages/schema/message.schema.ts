import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { User } from 'src/users/schema/user.schema';

export type MessageDocument = Message & Document;

@Schema({ timestamps: true })
export class Message {
  @Prop({ required: true })
  email: string;

  @Prop({ required: true, minLength: 2 })
  firstName: string;

  @Prop({ required: true, minLength: 2 })
  lastName: string;

  @Prop({
    required: false,
    type: mongoose.Schema.Types.ObjectId,
    ref: User.name,
  })
  user: User;

  @Prop({ required: true, minLength: 10 })
  message: string;

  @Prop({ required: false })
  note: string;
}

export const MessageSchema = SchemaFactory.createForClass(Message);
